import csv,hashlib,json,shutil
from pathlib import Path
import numpy as np
from tools.export_pressure_stages import render
from tools.export_pore_sections import render_sections
root=Path('results/random-packing-001');out=Path('exports/random-packing-progress-02776');out.mkdir(exist_ok=False)
segments=[('compression-001',6),('compression-007',1),('compression-018',1),('compression-021',3),('compression-022',1),('compression-025',1),('compression-026',2)]
rows=[];checks=[];previous=None;elapsed=0.
for name,last in segments:
    run=root/name
    if previous:
        with np.load(previous) as a,np.load(run/'state-0000.npz') as b:
            assert set(a.files)==set(b.files) and all(np.array_equal(a[k],b[k]) for k in a.files)
        checks.append(dict(previous=str(previous),restart=str(run/'state-0000.npz'),exact_arrays=True))
    with (run/'history.csv').open() as f:chosen=[dict(r) for r in csv.DictReader(f) if int(r['step'])<=last]
    assert int(chosen[-1]['step'])==last
    for r in chosen:
        r.update(source_run=name,source_step=r['step'],source_wall_s=r['wall_s']);r['step']=len(rows)+1;r['wall_s']=elapsed+float(r['wall_s']);rows.append(r)
    elapsed=float(rows[-1]['wall_s']);previous=run/f'state-{last:04d}.npz'
with (out/'accepted-history.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
with np.load(root/'compression-001/state-0000.npz') as f:initial=dict(f)
with np.load(previous) as f:loaded=dict(f)
c=json.loads((root/'compression-026/config.json').read_text());L=c['length_mm'];r=rows[-1]
render(out/'compression-02776.png',loaded,f"Random packing: accepted compression{100*float(r['compression']):.4f}%\nPorosity{100*float(r['porosity']):.4f}%; pressure{float(r['nominal_pressure_MPa']):.6f} MPa",L,footer='Actual FEM mesh, displacement scale1x; fixed transverse cell\nPartial path: target10% NOT reached; mesh / increment convergence unverified')
render_sections(initial,loaded,L,out/'pore-sections.png')
shutil.copy2(previous,out/'accepted-state-02776.npz')
for src,dst in [('equilibrium-prefix-02776.json','equilibrium-audit.json'),('volume-prefix-02776.json','volume-history-audit.json'),('adaptive-driver-tests.log','tests.log')]:shutil.copy2(root/src,out/dst)
shutil.copy2(root/'compression-026/config.json',out/'solver-config.json')
(out/'provenance.json').write_text(json.dumps(dict(exact_restart_checks=checks,final_state_sha256=hashlib.sha256(previous.read_bytes()).hexdigest(),target_reached=False,wall_time_interpretation='Selected path only; excludes other branches and initial-guess preparation outside selected segments.'),indent=2)+'\n')
(out/'README.md').write_text('''# ランダム充填層の途中結果：27.76%圧縮

初期メッシュ空隙率40.4037%から18.0589%へ収束しました。公称圧力0.0832137 MPa。
両横周期寸法は24.109757 mmで固定、最大自由残差0.00477786 N（基準0.005 N未満）。
16粒子、球径10 mm、焼結ネック径2 mm、E=10 MPa、ν=0.33、摩擦0.3。
降伏0.05 MPa・硬化0.2 MPaは開発用仮値です。

**空隙率10%への工程4は継続中です。保持・除荷は未実施です。**
単一標本で、統計的等方性・メッシュ・増分収束は未認定です。

[実メッシュPNG](compression-02776.png)・[初期／圧縮の同縮尺断面](pore-sections.png)・[収束経路CSV](accepted-history.csv)・[保存状態NPZ](accepted-state-02776.npz)。
[独立した力・材料履歴・摩擦の再計算](equilibrium-audit.json)・[体積監査](volume-history-audit.json)・[80テスト](tests.log)・[厳密な再開履歴](provenance.json)・[計算設定](solver-config.json)。
CSVの時間は選択した経路だけの累積で、別分岐や経路外の初期推定作成時間を含みません。
断面図の白は空隙、灰色は圧縮後セル外。見出しの空隙率は3D体積による値です。
''')
print(out, len(rows), flush=True)
