import json,time
from pathlib import Path
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import lsmr
from packing_fem.explicit_material import geometry
from packing_fem.explicit_periodic import Periodic
from packing_fem.implicit_material import evaluate
from packing_fem.ipc_periodic import PeriodicIPC
root=Path('results/random-packing-001');run=root/'compression-026';out=root/'peak-lsmr-probe-03111.json';assert not out.exists()
with np.load(run/'state-0003.npz') as f:old=dict(f)
trace=run/'iterate-trace/iterate-1794214108924618397-0040.npz'
with np.load(trace) as f:q=f['q'].copy()
c=json.loads((run/'config.json').read_text());p=Periodic(old['X'],c['length_mm']);inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);contact=PeriodicIPC(old['X'],old['t'],p,c)
def values(v,tangent=False):
    _,gm,Km,st=evaluate(p.positions(v),old['t'],old['b'],old['ep'],inverse,old['V0'],dict(c,implicit_project_material_tangent=False),tangent,parent=old['parent'])
    _,gc,Kc,n=contact.evaluate_coupled(v,old['q'],tangent)
    g=(np.asarray(p.A.T@gm.ravel()).ravel()+gc)[:p.nmicro]
    J=None if not tangent else (p.A.T@Km@p.A+Kc)[:p.nmicro,:p.nmicro].tocsc()
    return g,J
start=time.monotonic();g,J=values(q,True);maximum=float(abs(g).max());merit=.5*maximum**2;norm=float(np.linalg.norm(g));active=abs(g)>=maximum*(1-1e-12);mg=np.asarray(J.T@np.where(active,g/max(active.sum(),1),0.)).ravel();rows=[]
for exponent in [1.,2.]:
    scale=np.maximum((abs(g)/maximum)**exponent,.05);A=diags(scale)@J;columns=1/np.sqrt(np.maximum(np.asarray(A.power(2).sum(axis=0)).ravel(),1e-12));A=A@diags(columns)
    linear=lsmr(A,-scale*g,damp=.01,atol=1e-4,btol=1e-4,maxiter=500);dq=np.zeros(p.ndof);dq[:p.nmicro]=columns*linear[0];slope=float(mg@dq[:p.nmicro]);row=dict(exponent=exponent,linear_iterations=int(linear[2]),slope=slope)
    if slope<0:
        bound=contact.ccd(q,dq);alpha=1. if bound>=1 else .9*bound
        for ls in range(16):
            try:
                candidate=q+alpha*dq;cg,_=values(candidate);cm=.5*float(abs(cg).max()**2)
                if cm<=merit+1e-4*alpha*slope and np.linalg.norm(cg)<=norm:
                    row.update(alpha=alpha,maximum_force_N=float(abs(cg).max()),l2_force_N=float(np.linalg.norm(cg)),maximum_ratio=float(abs(cg).max()/maximum));np.savez_compressed(root/f'peak-lsmr-probe-03111-{exponent:g}.npz',q=candidate,X=old['X'],t=old['t'],oldq=old['q'],b=old['b'],ep=old['ep']);break
            except (ValueError,RuntimeError):pass
            alpha*=.5
        else:row['rejected']=True
    else:row['rejected']=True
    rows.append(row);print(json.dumps(row),flush=True)
report=dict(initial_guess_only=True,accepted_solution=False,trace=str(trace),predecessor=str(run/'state-0003.npz'),initial_maximum_force_N=maximum,initial_l2_force_N=norm,candidates=rows,wall_s=time.monotonic()-start)
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
