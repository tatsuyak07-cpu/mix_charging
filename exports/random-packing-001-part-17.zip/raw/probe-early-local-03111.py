import json,time
from pathlib import Path
import numpy as np
from packing_fem.explicit_material import geometry
from packing_fem.explicit_periodic import Periodic
from packing_fem.implicit_material import evaluate
from packing_fem.ipc_periodic import PeriodicIPC
from packing_fem.quasistatic_coupled import equilibrium
root=Path('results/random-packing-001');run=root/'compression-026';out=root/'early-local-probe-03111.json';assert not out.exists()
with np.load(run/'state-0003.npz') as f:old=dict(f)
trace=run/'iterate-trace/iterate-1794214108924618397-0040.npz'
with np.load(trace) as f:q=f['q'].copy();assert np.array_equal(f['X'],old['X']) and np.array_equal(f['t'],old['t'])
c=json.loads((run/'config.json').read_text());c.update(implicit_local_force_threshold_multiplier=20.,implicit_coupled_max_iterations=1)
p=Periodic(old['X'],c['length_mm']);inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);contact=PeriodicIPC(old['X'],old['t'],p,c);logs=[]
def log(row):logs.append(row);print(json.dumps(row),flush=True)
start=time.monotonic();sol=equilibrium(p,old['t'],old['q'],old['b'],old['ep'],inverse,old['V0'],c,contact,float(q[p.prescribed]),np.zeros(p.ndof),log,old['parent'],q)
trial=sol['iterate'] if isinstance(sol,dict) else sol[0]
_,gm,_,st=evaluate(p.positions(trial),old['t'],old['b'],old['ep'],inverse,old['V0'],c,parent=old['parent']);_,gc,_,n=contact.evaluate_coupled(trial,old['q']);g=(np.asarray(p.A.T@gm.ravel()).ravel()+gc)[:p.nmicro]
report=dict(initial_guess_only=True,accepted_solution=False,trace=str(trace),predecessor=str(run/'state-0003.npz'),threshold_multiplier=20.,logs=logs,after_maximum_force_N=float(abs(g).max()),after_l2_force_N=float(np.linalg.norm(g)),contacts=n,minimum_volume_mm3=float(st['volume'].min()),wall_s=time.monotonic()-start)
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
