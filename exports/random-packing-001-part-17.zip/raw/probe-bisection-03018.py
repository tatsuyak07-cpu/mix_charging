import json,time
from pathlib import Path
import numpy as np
from packing_fem.explicit_material import geometry
from packing_fem.explicit_periodic import Periodic
from packing_fem.ipc_periodic import PeriodicIPC
from packing_fem.load_predictor import bisected_initial_guess
root=Path('results/random-packing-001');run=root/'compression-026';out=root/'bisection-probe-03018';assert not out.with_suffix('.json').exists()
with np.load(run/'state-0003.npz') as f:old=dict(f)
traces=sorted((run/'iterate-trace').glob('*.npz'),key=lambda p:p.stat().st_mtime)
trace=traces[-1]
with np.load(trace) as f:failed=f['q'].copy();assert np.array_equal(f['X'],old['X']) and np.array_equal(f['t'],old['t'])
c=json.loads((run/'config.json').read_text());p=Periodic(old['X'],c['length_mm']);prescribed=(old['q'][p.prescribed]+failed[p.prescribed])/2
assert -failed[p.prescribed]>.31
contact=PeriodicIPC(old['X'],old['t'],p,c);inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);start=time.monotonic()
q,report=bisected_initial_guess(p,old['t'],old['q'],failed,prescribed,old['b'],old['ep'],inverse,old['V0'],old['parent'],c,contact)
report.update(trace=str(trace),predecessor=str(run/'state-0003.npz'),target_compression=float(-prescribed),wall_s=time.monotonic()-start,accepted_solution=False)
out.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');np.savez_compressed(out.with_suffix('.npz'),q=q,X=old['X'],t=old['t'],oldq=old['q'],b=old['b'],ep=old['ep']);print(json.dumps(report),flush=True)
