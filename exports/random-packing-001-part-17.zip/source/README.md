# Periodic sphere-packing compression — solid FEM

**ランダム充填層の工程1〜4：載荷空隙率10%への試作計算が完了しました。**
16粒子・球径10 mm・焼結ネック径2 mmの有限変形固体FEMで、
初期メッシュ空隙率40.4037%から9.98696%へ到達しました。
軸圧縮率34.6854%、公称圧力0.162071 MPa。両横周期寸法24.109757 mmを維持しました。
接触中の再メッシュを通過し、全21保存状態の体積・境界監査、最終の力・摩擦・拡大周期画像監査に合格しました。
[最終メッシュPNG](exports/random-packing-001/loaded-mesh.png)・[空隙の中央断面比較](exports/random-packing-001/pore-sections.png)・[CSV・全結果](exports/random-packing-001/README.md)・[開発報告](docs/random-packing-development.md)。
保持・除荷は今回の範囲に含めていません。単一16粒子の試作で、統計的等方性・メッシュ・増分収束は未認定です。

**現在の指定：横方向の周期セル寸法を初期値に固定します。**
`Fbar=diag(1,1,lambda_z)` とし、圧縮・保持・ゼロ軸荷重への除荷を通してX・Yの周期ベクトルを維持します。
周期的な微視的変位の揺らぎは許し、横方向反力を記録します。
[固定セル用設定](configs/implicit-ipc-fixed-cell.json)・[変更内容](docs/fixed-transverse.md)。
前回のBCC試作メッシュの再計算では、軸方向35.40%圧縮時に空隙率10.05%へ到達。保持・ゼロ軸荷重回復も完走し、回復後は11.57%。
全27状態でX・Y周期寸法12.1 mmを維持しました。
[載荷メッシュ](exports/fixed-transverse-001/loaded-mesh.png)・[空隙率と横寸法](exports/fixed-transverse-001/porosity-and-cell-size.png)・[CSVと結果](exports/fixed-transverse-001/README.md)・[全データZIP](exports/fixed-transverse-001.zip)。
過去の横方向応力自由の設定・結果は比較用として残しています。

<!-- large-deformation-first -->
**前回（横方向応力自由）：有限変形の陰解法FEM＋IPC周期自己接触＋適応再メッシュへ変更し、95%圧縮まで実計算しました。**
最終空隙率25.816%、経路中の最小空隙率25.137%。**10%到達は未達成**です。
別分岐では57.5%圧縮・保持・ゼロ軸荷重への除荷を完走し、空隙率27.103%→28.943%、残留圧縮率55.593%を確認しました。
材料E=10 MPa、摩擦0.3と横方向応力自由の周期条件を維持。初期メッシュの測定空隙率は41.162%で、物理的なメッシュ・増分収束は未認定です。
保存51状態で正の四面体体積と非交差を確認し、周期画像27→125個で接触数・力・エネルギーが一致。関連28テスト合格。
[開発・計算報告](docs/large-deformation-first.md)・[大変形と永久変形の比較画像](exports/large-deformation-first-001/demonstration-cycle.png)・[95%圧縮メッシュ](exports/large-deformation-first-001/latest-mesh.png)・[空隙率曲線](exports/large-deformation-first-001/porosity-path.png)・[CSVと結果一覧](exports/large-deformation-first-001/README.md)・[全データZIP](exports/large-deformation-first-001.zip)。
<!-- /large-deformation-first -->

**前回：工程1〜3を実装・比較し、対象4面の点追加と履歴再計算で旧停止区間を通過しました。**
埋込積分点96→197点、90,262→90,273刻み。物理時刻でも通過を確認し、関連92テストが合格。早期再配分の独立した改善効果は充填層では未確認で、新しい積分誤差による停止が残ります。空隙率40%→10%・保持/除荷・収束確認は未達成です。
[工程1〜3の報告](docs/stages123-development.md)・[比較図](exports/stages123-development-001/comparison.png)・[積分点配置](exports/stages123-development-001/quadrature-points.png)・[メッシュ](exports/stages123-development-001/packing-mesh.png)・[CSV・結果一覧](exports/stages123-development-001/README.md)・[データZIP](exports/stages123-development-001.zip)。

**前回：再配分の成分別予算を共有L1予算へ修正し、受理済み状態の誤った除外を解消しました。**
関連84テスト・平面接触6条件に合格。実充填層は次配置の保存射影が実行不能で、90,262刻みの停止は未解消です。空隙率40%→10%・保持/除荷・収束確認は未達成です。
[検証報告](docs/l1-budget-verification.md)・[検証画像](exports/l1-budget-verification-001/verification.png)・[メッシュ](exports/l1-budget-verification-001/packing-mesh.png)・[CSV・結果一覧](exports/l1-budget-verification-001/README.md)・[データZIP](exports/l1-budget-verification-001.zip)。

**前回：時間発展中の保存再配分を追加し、平面接触6条件と関連73テストに合格しました。**
実充填層では保存制約付きの再配分が実行不能となり、前回と同じ90,262刻みで停止しました。空隙率40%→10%の完走は未達成です。
[検証報告](docs/runtime-parent-verification.md)・[比較画像](exports/runtime-parent-verification-001/verification.png)・[実メッシュ](exports/runtime-parent-verification-001/packing-mesh.png)・[CSV・結果一覧](exports/runtime-parent-verification-001/README.md)・[データZIP](exports/runtime-parent-verification-001.zip)。

**前回：親面全体の積分監査と、力・エネルギー・履歴を保つ既存積分点の重み再配分を実装しました。**
実充填層で接触中の再メッシュを承認し、その後12刻み継続しました。以後の積分精度不足で停止しており、空隙率40%→10%・保持/除荷完走・収束確認は未達成です。
[開発報告](docs/parent-hybrid-development.md)・[検証画像](exports/parent-hybrid-development-002/verification.png)・[実メッシュ](exports/parent-hybrid-development-002/packing-mesh.png)・[CSVと判定](exports/parent-hybrid-development-002/README.md)・[データZIP](exports/parent-hybrid-development-002.zip)。
以下は今回の開発に至る各工程の記録です。

現在の到達目標を**載荷・平衡状態の空隙率40%→10%**に限定し、圧密・保持・除荷の制御と内部再接続を追加しました。
実充填層は空隙率37.61%までの保持が合格。接触開始後の44刻みを3水準の積分誤差予算で通過しました。**10%到達・除荷完走・空間収束確認は未達成**です。
[今回の開発報告](docs/porosity-cycle-development.md)・[平衡保持CSV](exports/porosity-cycle-development-001/equilibrated-holds.csv)・[実メッシュ画像](exports/porosity-cycle-development-001/last-equilibrated-mesh.png)・[データZIP](exports/porosity-cycle-development-001.zip)。
工程1・2では、過去姿勢を保持する接触積分と摩擦履歴の再実行を接続し、保守的な境界箱探索を追加しました。同じ98,320接触候補を保ち、広域候補を1,569,093→489,681件へ削減。
[工程1・2の報告](docs/contact-atlas-development.md)・[検証画像](exports/contact-atlas-development-001/coupled-prefix.png)・[CSV](exports/contact-atlas-development-001/coupled-contact-prefix.csv)・[全データZIP](exports/contact-atlas-development-001.zip)。短区間の検証であり、圧密完走の結果ではありません。

工程3では、積分点・摩擦履歴を保つ限定的な面分割に加え、速度の保存射影、同距離投影の参照積分、過去姿勢の子面への移行を追加しました。速度のある平面接触の分割・保存/再開・3刻み継続がCFL 3水準で合格。**実充填層の接触面3辺は積分点と子面面積が整合せず、工程3全体は未完了**です。
[今回の修正報告](docs/remesh-corrections.md)・[保存誤差の比較](exports/remesh-corrections-001/conservation-errors.png)・[CSV](exports/remesh-corrections-001/comparison.csv)・[データZIP](exports/remesh-corrections-001.zip)。
[前段の履歴移行・固着アンカー修正](docs/active-embedded-remesh.md)では、平面接触6条件の逆すべり・離間を比較しています。

保存充填層の接触4面・全10辺を追加検証しました。既存の点・重みを保持したまま面積条件を満たす分割位置は、8辺で必要な積分則がなく、残る2辺でも隣接面の許容位置が一致せず、**適用可能0/10**でした。分割位置を変えるだけでは解消できません。
[分割位置の検証報告](docs/cut-balance-verification.md)・[比較図](exports/cut-balance-verification-002/cut-balance.png)・[CSV・全データZIP](exports/cut-balance-verification-002.zip)。

以下は過去の各工程の記録です。過去の0.1 MPa目標は今回の完了条件に含みません。


三角形面の接触積分を検証：**狭い辺・頂点接触24条件、分割位置12条件、関連30テストに合格**。
[検証報告](docs/triangle-integration.md)・[誤差比較図](exports/triangle-integration-001/integration-errors.png)・[積分点分布](exports/triangle-integration-001/quadrature-points.png)・[全データZIP](exports/triangle-integration-001.zip)。
摩擦なしの有限三角形対の単体検証です。周期パッチ探索・摩擦履歴との接続・0.1 MPaの圧縮完走は未完了です。

追加する接触積分点の前提を検証：**接触前からの摩擦履歴再生12条件、狭い帯の積分18条件に合格**。
[検証報告](docs/integration-replay.md)・[履歴比較図](exports/integration-replay-002/history-replay.png)・[積分比較図](exports/integration-replay-002/narrow-integration.png)・[全データZIP](exports/integration-replay-002.zip)。
関連17テスト合格。規定運動の平面接触・既知形状の帯での単体検証です。2次元面積分、圧縮ソルバーの巻き戻し・接続、0.1 MPaの平衡到達は未完了です。

摩擦履歴・接触積分を保持する `material` モードを実装：**過去の拒否提案で面積・法線エネルギーを保持し、10項目の移行監査に合格**。
[検証報告](docs/material-quadrature.md)・[比較図](exports/material-quadrature-001/energy-conservation.png)・[新設定](configs/packing-rve-material-quadrature.json)・[全データZIP](exports/material-quadrature-001.zip)。
全体300テスト合格。固着・滑りの履歴と力評価状態を分けて移行します。積分点の適応追加は未実装で、0.1 MPaの完走は未達成です。

工程1〜4を比較検証：**辺対の接触確認を修正し、7条件を計算。0.1 MPa載荷・保持と準静的条件は未合格**。
[検証報告](docs/compaction-stages-1-4.md)・[比較図](exports/compaction-stages-001/stage4-comparison.png)・[条件別CSV](exports/compaction-stages-001/case-outcomes.csv)・[全データZIP](exports/compaction-stages-001.zip)。
全体284テスト合格。実充填セルでは新しい接触点の履歴不足と接触積分の変化で停止し、載荷速度による空隙率差も残っています。停止時の値を平衡圧密の結果として扱っていません。

ほぼゼロ離隔の辺対を検証：**丸め誤差による誤った除外判定を修正し、端点接触だけでは不十分な確認条件も特定**。
[検証報告](docs/near-edge.md)・[判定比較図](exports/near-edge-001/near-edge-checks.png)・[局所形状図](exports/near-edge-001/near-edge-geometry.png)・[全データZIP](exports/near-edge-001.zip)。
33条件の座標感度と局所三角形の非交差を確認しました。辺対ごとの接触確認条件は未修正で、今回の圧縮再計算は行っていません。

分割候補の自動選択と棄却試行の再実行を接続：**前回の停止区間を4回の監査付き分割で通過**。
[検証報告](docs/closest-selection.md)・[比較画像](exports/closest-selection-001/selection-comparison.png)・[停止時メッシュ](exports/closest-selection-001/stopped-mesh.png)・[全データZIP](exports/closest-selection-001.zip)。
全体267テスト合格。再計算は約0.05872 MPaで幾何チェックによる刻み下限に達して停止しました。空隙率約33.87%は未平衡の途中状態で、0.1 MPaの圧密解ではありません。

非中点分割の状態・摩擦履歴を検証：**保存状態の両分割案が移行監査に合格**。
[検証報告](docs/weighted-surface-transfer.md)・[比較画像](exports/weighted-transfer-001/weighted-transfer.png)・[全データZIP](exports/weighted-transfer-001.zip)。
追加接触節点への重み付き摩擦履歴の補間と、その後の滑りも確認しました。圧縮ソルバーへの自動選択・再試行の組み込みは未完了です。

表面分割の集中を検証：**最後の停止候補では中点分割が接触範囲を外れることを確認**。
[検証報告](docs/refinement-diagnostics.md)・[分割位置の比較図](exports/refinement-diagnostics-001/insertion-comparison.png)・[全データZIP](exports/refinement-diagnostics-001.zip)。
関連31テスト・幾何診断16項目に合格。相手側の辺を最短位置で分割する案は品質を保ちますが、状態・摩擦履歴の移行と圧縮計算への組み込みは未検証です。

周期変位移行修正後の全履歴を再検証：**移行エラーは解消したが、表面分割16回の上限で停止**。
[検証報告](docs/packing-rve-replay.md)・[比較図](exports/packing-rve-replay-001/replay-comparison.png)・[停止時メッシュ](exports/packing-rve-replay-001/stopped-mesh.png)・[全データZIP](exports/packing-rve-replay-001.zip)。
関連35テスト合格。約0.05674 MPa・空隙率34.27%は未平衡の途中状態であり、0.1 MPaの準静的解ではありません。

工程4の小周期セルを実装：**10 mm球・2 mmネックのBCC焼結セルで低荷重の周期圧縮を検証**。
[開発・検証報告](docs/packing-rve-development.md)・[比較図](exports/packing-rve-001/packing-rve-validation.png)・[実メッシュ](exports/packing-rve-001/actual-packing-mesh.png)・[全データZIP](exports/packing-rve-001.zip)。
初期空隙率39.84375%。0.001 MPaの対照を独立な線形FEM解・力の再積分・刻み半減と比較しました。
接触停止からの辺分割・再試行、等距離最短点の劣勾配、周期変位の直接移行、検証付きC++要素カーネルを追加。
**0.1 MPaまでの準静的大変形、表面の品質回復、メッシュ収束、40%→10%圧密は未完了**です。大荷重の保存状態を平衡解として扱っていません。

工程1〜3の試験実装：**参照材料近傍の幾何条件、別パッチの複数接触、周期表面の辺分割と状態・摩擦履歴の移行を追加**。
[開発・検証報告](docs/surface-development.md)・[分割前後の画像](exports/surface-bisection-view-001/surface-bisection.png)・[判定結果](exports/surface-development-003/summary.json)・[全データZIP](exports/surface-development-003.zip)。
全体224テスト・診断10項目に合格。小さな圧力対照で分割後の継続と解析解を検証し、接触専用試験で摩擦履歴・エネルギー・巨視的接触力の移行を確認。
通常設定は維持しています。一般の表面再生成、真の辺接触の力積分、接触積分のメッシュ収束は未完了で、40%→10%圧密の結果ではありません。

変形写像の非重複条件を検証：**保存形状を補間した5段階すべてで、形状だけの十分条件が合格**。
[検証報告](docs/structured-extension.md)・[画像](exports/structured-extension-001/geometry-extension.png)・[CSV](exports/structured-extension-001/geometry-certificate.csv)・[全データZIP](exports/structured-extension-001.zip)。
空隙内の補助写像を用い、材料節点・物理体積・接触力を保持しました。関連17テストと診断10項目が合格。
接触力の削除や停止ガード解除には接続していません。細分化した圧力一周期・メッシュ収束・40%→10%圧密は未完了です。

点対面の源・相手を分けて検証：**源側の距離減少だけで正常な積分点を除外する案を反例で棄却**。
[検証報告](docs/point-stationarity.md)・[診断画像](exports/point-stationarity-001/point-stationarity.png)・[積分点CSV](exports/point-stationarity-001/wave-quadrature.csv)・[全データZIP](exports/point-stationarity-001.zip)。
全体テスト197件と診断7項目が合格しました。追加は診断専用で、接触力・停止ガードは維持しています。
変形後の細分化4・6、圧力一周期のメッシュ収束、40%→10%圧密は未解決です。

辺候補の表面最短条件を検証：**試験機能で初期形状の全5段階が評価可能、変形後の4・6は引き続き停止**。
[検証報告](docs/edge-stationarity.md)・[候補画像](exports/edge-stationarity-002/edge-stationarity.png)・[CSV](exports/edge-stationarity-002/mesh-status.csv)・[全データZIP](exports/edge-stationarity-002.zip)。
全体テスト189件に合格。真の辺接近の停止ガードと周期平面接触の反力を維持しました。試験機能の通常設定は無効です。
細分化した圧力一周期・メッシュ収束・40%→10%圧密は未完了です。

局所材料近傍の候補判定を追加：**角部の点対面候補を区別し、未解決の辺接近では停止を維持**。
[検証報告](docs/local-material-neighborhood.md)・[候補画像](exports/local-material-neighborhood-001/local-material-candidates.png)・[停止理由CSV](exports/local-material-neighborhood-001/error-comparison.csv)・[全データZIP](exports/local-material-neighborhood-001.zip)。
全体179件・追加を含む重点8件のテストに合格。周期接触と保存済み空隙壁接触で反力の一致を確認しました。
細分化4・6の事前検査は引き続き不合格です。細分化した圧力一周期・メッシュ収束・40%→10%圧密は未完了です。

メッシュ細分化の事前検査：**細分化4・6で初期形状の接触候補が解決できず、不合格**。
[検証報告](docs/contact-mesh-preflight.md)・[実メッシュと候補の画像](exports/contact-mesh-preflight-002/mesh-preflight.png)・[CSV](exports/contact-mesh-preflight-002/mesh-comparison.csv)・[診断データZIP](exports/contact-mesh-preflight-002.zip)。
同じ変形形状でも粗い3段階の法線接触エネルギーは1、1/4、1/9と変化しました。形状・体積・周期性の移送検査と関連テスト4件は合格。
局所的な空隙壁の角部を接触候補から区別する修正が必要です。細分化した圧力一周期・メッシュ収束・40%→10%圧密は未完了です。

接触・塑性・除荷一周期のCFL半減を検証：**0.2→0.1で全比較項目が合格**。
[検証報告](docs/contact-cycle-cfl.md)・[比較PNG](exports/contact-cycle-cfl-001/cfl-comparison.png)・[差分CSV](exports/contact-cycle-cfl-001/path-differences.csv)・[全結果ZIP](exports/contact-cycle-cfl-001.zip)。
残留ひずみ差5.61e-9、全過程の最大空隙率差1.14e-8。細刻み終点の独立反力監査と関連テスト4件も合格しました。
4 mm・初期空隙率0.25%の検証セルでの一回の刻み半減です。メッシュ収束・球充填体の40%→10%圧密は未完了です。

接触反力を独立監査：**摩擦履歴と反力評価時の状態を保存し、エネルギーの数値微分・材料面力積分で終点反力を照合**。
[検証報告](docs/contact-reaction-audit.md)・[比較PNG](exports/contact-reaction-audit-001/contact-audit.png)・[監査CSV](exports/contact-reaction-audit-001/reaction-audit.csv)・[全結果ZIP](exports/contact-reaction-audit-001.zip)。
4 mm検証セルの同条件再計算で全ステップ数値・最終8配列が前回と完全一致。独立反力監査と全テスト169件に合格しました。接触探索・接触一周期のCFL感度・メッシュ収束・球充填体の40%→10%圧密は未完了です。

塑性・接触後の除荷を検証：**0.1 MPaから除荷後、残留圧縮約22.0712%、空隙率約0.22173%**。
[検証報告](docs/plastic-contact-unloading.md)・[比較PNG](exports/plastic-contact-unloading-001/plastic-unloading.png)・[実メッシュ](exports/plastic-contact-unloading-001/residual-mesh.png)・[CSV・全結果ZIP](exports/plastic-contact-unloading-001.zip)。
4 mm角・初期空隙率0.25%の検証用セルで、除荷8/16 msの両条件が既存検査に合格しました。関連テスト27件合格。この保存結果は独立反力監査に必要な摩擦履歴を含みません。接触一周期の刻み・メッシュ収束、球充填体の40%→10%圧密は未完了です。

除荷判定を追加検証：**有限変形弾性解と刻み・速度比較で、ゼロ荷重近傍の瞬間KE比の分母の影響を確認**。
[検証報告](docs/unload-quasistatic-verification.md)・[比較PNG](exports/unload-quasistatic-verification-001/unload-sensitivity.png)・[CSV・全計算ZIP](exports/unload-quasistatic-verification-001.zip)。
関連テスト24件合格。急速荷重を棄却できることも確認しました。補助検査と既存の総合判定を区別し、塑性・接触後の除荷と球充填体の圧密は未検証です。

連結セルの追加検証：**初期剛性を3段階で細分化し、弾性圧縮・除荷の対照試験を実施**。
[結果・判定](docs/connected-refinement-unloading.md)・[比較PNG](exports/connected-refinement-unloading-002/refinement-unloading.png)・[全データZIP](exports/connected-refinement-unloading-002.zip)。
形状は復元しましたが、除荷終盤の既存KE比判定は不合格のため診断データとして保持しています。塑性除荷・球充填体の40%→10%圧密は未完了です。

連結多孔質セルで真応力圧縮を検証：**全採用ステップの監査CSVを追加**。
[条件・判定・適用限界](docs/connected-pressure-verification.md)・[比較PNG](exports/connected-pressure-verification-001/connected-pressure-verification.png)・[全データZIP](exports/connected-pressure-verification-001.zip)。
4 mm角・初期空隙率0.25%の検証用形状です。球充填層の40%→10%圧密は未完了です。

接触過渡を追加検証：**層状セルに接触前の無剛性モードを確認**。
[検証条件・判定](docs/layered-contact-transient.md)・[比較PNG](exports/layered-contact-transient-001/layered-contact-verification.png)・[全データZIP](exports/layered-contact-transient-001.zip)。
接触後の終点の釣合いと、全過程の準静的性を分けて評価します。球充填体の圧密完了を意味しません。

大変形の圧力指定を改善：**一軸Cauchy真応力の追従荷重 `cauchy_pressure` を追加**。
[式・検証・適用限界](docs/objective-pressure.md)・[比較PNG](exports/objective-pressure-001/pressure-verification.png)・[結果ZIP](exports/objective-pressure-001.zip)。
従来の公称荷重方式は保持しています。今回の実荷重試験は空隙のない検証立方体です。
接触過渡と球充填層の40%→10%圧密の完了を意味しません。

接触積分を修正：**参照面積による `area_guarded` を追加し、平面32ケースの位置依存検査に合格**。
[実装・検証・適用限界](docs/area-contact-fix.md)・[比較PNG](exports/area-contact-fix-002/area-contact-verification.png)・[結果ZIP](exports/area-contact-fix-002.zip)。
辺だけの接触・複数パッチは解像不足として停止します。100 mm充填層の40%→10%圧密は未完了です。

従来方式の検証記録：**平面接触のメッシュ位置依存を確認し、物理検証に不合格**。
同じ間隙でも接触力が約4.5倍異なるため、従来方式の圧密値を物理予測に採用しません。
[結果・原因・修正に必要な条件](docs/plane-contact-verification.md)・[比較PNG](exports/plane-contact-verification-001/plane-contact-dependence.png)・[検証データZIP](exports/plane-contact-verification-001.zip)。

最新の開発：**周期自己接触を含む陽解法FEMの圧力・空隙率制御**。[実装・検証・適用限界](docs/barrier-compaction.md)。
4 mmの検証セルで0.1 MPaまで計算。100 mmの球充填層／空隙率40%→10%の計算は未完了です。
[結果ZIP](exports/barrier-compaction-002.zip)・[圧力と空隙率](exports/barrier-compaction-002/pressure-porosity.png)・[実メッシュ](exports/barrier-compaction-002/mesh-at-pressure.png)。
以下には過去の条件・計算記録も保持しています。

追加検証：**焼結ネックの形状固定細分化とC3D8/C3D8I比較**。[条件と判定](docs/neck-element-verification.md)。
C3D8Iの部品応答は最細分比較で2%基準内。局所塑性ひずみ・周期充填層全体は未検証です。

追加検証：**刻み幅・材料感度・メッシュ・仕事の6ケース比較**。[結果と適用限界](docs/plastic-verification.md)。
刻み幅の影響は小さい一方、メッシュ収束は未達です。

追加モデル：**温度依存性なし・大変形弾塑性の試験モデル**。[仮の物性・圧縮除荷手順・適用範囲](docs/plastic-trial.md)。
専用コマンドは `python -m packing_fem.plastic`。自己接触と0.1 MPa到達の検証は今後の段階です。

最新の追加計算：**E=10 MPa・圧縮応力0.1 MPa** は小ひずみ基準に不合格の診断用です。[計算記録と適用限界](docs/sintered-10mpa.md)。

最新の追加計算：**E=1 GPa・圧縮応力0.1 MPa**。[変形後メッシュ画像と結果](docs/sintered-1gpa.md)。
設定は `configs/sintered-1gpa.json`、従来の70 GPa設定は比較用に保持しています。

従来の静解析モデルは直径10 mmの球と直径2 mmの焼結ネックを一体化した試験骨格です。
CalculiX 2.20の静的有限要素法で圧縮と空隙率変化を計算します。円柱剛体は含みません。
DEMやHertzばねモデルで有限要素法を代替していません。

初期の静解析仕様（最新の圧密仕様は上記リンク）：100 mm角、ネック込みの初期空隙率60%（離散形状の許容差±0.2ポイント）、
骨格E=70 GPa、ν=0.33、粒子間は焼結接合、
一軸圧縮の目標Cauchy応力0.1 MPa、横方向平均応力ゼロ、空隙内圧ゼロ。
焼結モデルと限界は [docs/sintered.md](docs/sintered.md)。旧非接着モデルは
[docs/model.md](docs/model.md)、旧検証記録は
[docs/validation.md](docs/validation.md) に記載します。

## 実行

クラウド環境では以下を使用します。セットアップは計算と別に実行します。

```bash
cd /workspace/mix_charging
source /workspace/environment/mix_charging/.venv/bin/activate
export MPLCONFIGDIR=/workspace/environment/mix_charging/mplconfig
export XDG_CACHE_HOME=/workspace/environment/mix_charging/cache
export MPLBACKEND=Agg

# 本仕様の粒子配置と計算規模を確認。有限要素の本計算はまだ開始しない。
python -m packing_fem.cli estimate --config configs/baseline.json --output results/estimate-001

# 30 mm角の焼結骨格で動作検証。100 mm角の本仕様とは区別する。
python -m packing_fem.cli run --config configs/sintered-smoke.json --output results/sintered-test-001

# 本仕様の有限要素入力を生成。大規模モデルなので明示的な指定が必要。
python -m packing_fem.cli prepare --config configs/baseline.json --output results/baseline-001 --allow-large

# 入力生成後に実計算。時間制限は秒単位で、1回のsolver実行に適用される。
python -m packing_fem.cli solve results/baseline-001 --timeout 600

python -m pytest -q
```

既存出力フォルダは拒否します。別名で実行してください。計算中のネットワーク通信や
依存インストールはありません。`--solver` で別のCalculiX実行ファイルを指定できます。
通常のLinuxではBLAS/LAPACK、ARPACK、SPOOLESが必要です。

## 出力と判定

焼結モデルは `sintered.inp/.log/.dat`、`sintered-summary.json`、
`sintered-deformed.vtu`、`sintered-linear-history.csv/.png` を生成します。
履歴は静的線形解の比例荷重によるものです。ボクセル近似・ネック形状と
メッシュ収束の限界は [焼結モデル仕様](docs/sintered.md) を確認してください。

以下は保持している旧非接着モデルの出力です。

- `metadata.json`：物理条件、数値設定、球とメッシュの初期体積誤差。
- `model.inp`、`cycle-XX.inp`：実際に実行する有限要素入力と荷重履歴。
- `cycle-XX.log/.dat/.sta/.frd`：ソルバーのログと元の結果。
- `cycle-XX-history.csv/.png`：応力、セル寸法、空隙率、エネルギーの履歴。
- `cycle-XX-last-accepted.vtu`：最後にソルバーが受理した増分の粒子変形。
  このファイルがあるだけでは平衡解の成立を意味しません。ParaView等で表示できます。
- `cycle-XX-summary.json`：収束、応力、貫入、体積、運動、接触候補の検査。

元のソルバー応力は周期コピー数で分割した材料の値です。粒子の局所物理応力には
コピー数を掛ける必要があります。CSVの巨視的応力は全コピーを集計して補正済みです。

`diagnostics_only` は物理的な結果として採用しません。CLIも終了コード2を返します。
全検査を通った場合でも `equilibrium_candidate_requires_refinement` とし、
メッシュ・接触ペナルティ・粒子配置・緩和設定への依存性は別途検証します。
完全な検証済み解を自動的に宣言する状態は設けていません。

## 設定

`configs/baseline.json` は10 mm焼結モデル、`configs/sintered-smoke.json` は小規模試験用。
球だけなら764個、接合体積込みで空隙率を合わせた現試験骨格は750個です。

以下は旧5 mm非接着モデルの設定説明です。旧本仕様は
`configs/baseline-5mm-unbonded.json`、旧動作検証用は `configs/smoke.json`。
球体積と整数粒子数から、本仕様では6,112粒子、解析的空隙率59.9970535%になります。
曲面を近似する二次四面体C3D10を既定とし、理想球と有限要素メッシュの空隙率は
別々に表示します。`mesh_order: 1` によるC3D4も診断用に使用できます。

数値的な密度、セル制御の慣性、減衰、緩和時間、接触ペナルティは物性の追加指定では
ありません。準静的平衡を探すための開発者定義の設定で、測定密度や実際の時間とは
解釈しません。結果採用前に変更して解が変わらないことを確かめる必要があります。

## GitHubから結果を取得

CSV・PNG・計算記録は [exports](exports/README.md) に収録しています。
クラウドの環境構築には `bash tools/setup_cloud.sh` を使用します（uvが必要）。

最新の[工程1〜5の実装・検証報告](docs/pressure-stages.md)では、埋め込み材料積分、摩擦履歴の再生、完全状態の保存・再開、段階圧力制御を追加しました。
小さなBCCセルで0.001・0.01 MPaの平衡保持に合格しましたが、接触開始直後の再積分要求が続き、0.03 MPaの保持と0.1 MPaへの到達は未確認です。
[段階CSV・メッシュ画像・全試行](exports/pressure-stages-001/)を収録しています。

続く[接触開始時の積分誤差の検証](docs/onset-budget.md)では、微小量の絶対誤差床を見直した試験案を独立積分・実セル形状で比較しました。
参照積分の比較は合格しましたが、初期積分点を固定した変形後の評価は8条件中5条件が不合格でした。圧縮ソルバーへの組込みと摩擦履歴を伴う再生は次の検証です。

[大変形への到達可能性と開発方針の見直し](docs/large-deformation-feasibility.md)では、方式としてのFEMの妥当性と、現行コードの未対応機能を分けて評価しています。
接触・履歴・ゆがみ回復を一体で通す小規模実証を先に置き、0.1 MPa保持、空隙率10%、100 mm化を別々の判定工程とします。新しい圧縮結果を報告したものではありません。

周期C3D8Iの内部モード・仕事・圧縮分割数の追加検証は
[検証報告](docs/periodic-incompatible-verification.md)に記載しています。
25 mm角・1%圧縮の実験用モデルです。100 mm角・0.1 MPaやメッシュ収束は未検証です。

荷重を増加させた[空隙率の試験計算](docs/pressure-ramp.md)と
[CSV・PNG](exports/README.md#荷重増加と空隙率探索計算)を追加しました。
体積評価の監査条件を超えて停止しており、0.1 MPaまでの検証済み曲線は得られていません。

[初期40%から目標10%を目指す圧縮試算](docs/porosity40-to10.md)を追加しました。
設定は [porosity40-to10-trial.json](configs/porosity40-to10-trial.json)。
実際の初期メッシュ空隙率は39.8592%、体積監査で停止しており10%には未到達です。

空隙率40%から10%を扱うための[大変形計算手法の変更案](docs/large-deformation-method-review.md)をまとめました。
準静的陽解法FEM・周期自己接触・適応再メッシュを第一候補とし、MPM等との比較と導入時の検査を記載しています。

[準静的陽解法FEM・周期自己接触・局所再メッシュの研究用初版](docs/explicit-prototype.md)を実装しました。
[検証画像・CSV・準備済みモデル](exports/explicit-fem-prototype-002/)と[ZIP](exports/explicit-fem-prototype-002.zip)を収録しています。
内部再接続は実装済みですが、自由表面の全面再生成や40%→10%の圧密計算は未検証です。

次段階の検討: [周期接触の不連続・計算負荷と検証順序](docs/explicit-contact-next-review.md)。接触辺の通過時に生じるエネルギーの跳びを特定し、時間刻み半減でも残ることを確認しました。

接触の次段階検証: [面・凹辺・凹頂点の最近点処理と力・エネルギーの検証](docs/contact-feature-verification.md)。閉じた表面の試験用処理であり、圧縮ソルバーへの組込みは未実施です。

[周期切断面の内外判定と既知の接触領域の摩擦履歴の検証](docs/periodic-friction-verification.md)を追加しました。試験用演算子の検証であり、圧縮ソルバーへの組込みと接触領域の自動追跡は未実施です。

[接触追跡・接触中の内部再接続・研究用圧縮ソルバー結合の検証](docs/tracked-solver-integration.md)を追加しました。動的な節点接触の力の結合は確認しましたが、一般のスリット試験は未実装の辺―辺反力を必要とするため停止します。

[辺―辺の内部接触の反力・摩擦とソルバー結合](docs/interior-edge-contact.md)を追加しました。辺の反力は有効になりましたが、節点―面へのエネルギー整合な切替えで停止する研究用実装です。
