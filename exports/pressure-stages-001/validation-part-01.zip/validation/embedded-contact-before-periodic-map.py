"""Material surface quadrature embedded in the existing guarded friction law.

Virtual points have no mass/DOFs. Forces and stiffness majorants are pulled
back by the transpose of their exact material interpolation. Rule changes
require replay from a known inactive initial state, never history interpolation.
"""
from copy import deepcopy
import numpy as np
from scipy.sparse import csr_matrix
from scipy.spatial import cKDTree
from .area_contact import AreaContact,SurfaceResolutionError
from .explicit_periodic import Periodic
from . import surface_patch


class EmbeddedContact:
    def __init__(self,X,t,periodic,kn,mu,skin,quadrature_rules=None,quadrature_tolerance=.001,**kwargs):
        self.X=np.array(X,copy=True);self.periodic=periodic;self.rules=deepcopy(quadrature_rules or {});self.quadrature_tolerance=quadrature_tolerance
        kwargs.pop('quadrature_mode',None)
        # Discover the same physical/cell-cut faces as the existing backend.
        base=AreaContact(X,t,periodic,kn,mu,skin,quadrature_mode='material',**kwargs)
        faces=base.faces;N=len(X);rows=list(range(N));cols=list(range(N));values=[1.]*N
        added=[];virtual_faces=[];areas=base.integration_area0.copy();self.face_points={}
        for key,rule in sorted(self.rules.items(),key=lambda item:int(item[0])):
            face=int(key);B=np.asarray(rule['bary'],float);weights=np.asarray(rule['weights'],float)
            ids=faces[face];tri=X[ids];A=np.linalg.norm(np.cross(tri[1]-tri[0],tri[2]-tri[0]))/2
            if B.ndim!=2 or B.shape[1]!=3 or weights.shape!=(len(B),) or np.min(B)<-1e-12 or np.max(abs(B.sum(1)-1))>1e-12 or np.any(weights<=0) or abs(weights.sum()-A)>max(1e-12,A*1e-10):raise ValueError('Invalid full-reference-face quadrature rule')
            areas[ids]-=A/3;nodes=[]
            for bary,w in zip(B,weights):
                node=N+len(added);added.append((bary@tri,float(w)));virtual_faces.append(face);nodes.append(node)
                rows.extend([node]*3);cols.extend(ids);values.extend(bary)
            self.face_points[face]=(np.asarray(nodes),B,weights)
        if np.min(areas)<-1e-10:raise ValueError('Negative residual nodal integration area')
        self.P=csr_matrix((values,(rows,cols)),shape=(N+len(added),N));augX=self.P@X
        self.inner=AreaContact(augX,t,Periodic(augX,periodic.L),kn,mu,skin,quadrature_mode='material',**kwargs)
        guard=self.inner.guard;guard.node_area0[:N]=np.maximum(areas,0.)
        if added:guard.node_area0[N:]=np.array([p[1] for p in added])
        self.inner.quadrature_weights=guard.node_area0.copy();guard.nodes=np.r_[base.nodes,np.arange(N,len(augX))]
        original_adjacent=guard.adjacent
        def adjacent(node,face,shift):
            if node<N:return original_adjacent(node,face,shift)
            source_face=faces[virtual_faces[node-N]]
            return any(original_adjacent(int(k),face,shift) for k in source_face)
        guard.adjacent=adjacent
        for node,face in enumerate(virtual_faces,N):
            self.inner.peers[node]=set(map(int,faces[face]))
            if self.inner.material_neighborhood is not None:
                self.inner.material_neighborhood.components[node]=self.inner.material_neighborhood.components[faces[face,0]]
        self.nodes=base.nodes;self.faces=faces;self.node_area0=base.node_area0.copy();self.quadrature_mode='embedded'
        self._base_coverage=self.inner.edge_coverage
        self.inner.edge_coverage=self
        self._candidate_build=-1

    def __getattr__(self,name):return getattr(self.inner,name)
    @property
    def history(self):return self.inner.history
    @history.setter
    def history(self,value):self.inner.history=value
    @property
    def capture_audit(self):return self.inner.capture_audit
    @capture_audit.setter
    def capture_audit(self,value):self.inner.capture_audit=value
    @property
    def integration_area0(self):return np.asarray(self.P.T@self.inner.integration_area0).ravel()
    def edge_stiffness_diagonal(self):return np.asarray(self.P.T@self.inner.edge_stiffness_diagonal()).ravel()
    def accept_geometry(self,x,H):self.inner.accept_geometry(self.P@x,H)
    def replay_force_state(self,x,velocity,H):
        self._certificates={};self._x=x;self._H=H
        response=self.inner.replay_force_state(self.P@x,self.P@velocity,H)
        return self._collapse(response)
    def _collapse(self,response):return np.asarray(self.P.T@response[0]),response[1],response[2],response[3]
    def evaluate(self,x,velocity,H,Hdot,dt):
        self._certificates={};self._x=x;self._H=H
        return self._collapse(self.inner.evaluate(self.P@x,self.P@velocity,H,Hdot,dt))
    def update_topology(self,t):self.inner.update_topology(t)

    def _candidates(self):
        guard=self.inner.guard
        if self._candidate_build==guard.neighbor_builds:return
        # Same Verlet skin and motion rebuild schedule as the guarded search.
        x=self._x;H=self._H;tri=x[self.faces];center=tri.mean(1)
        radius=np.linalg.norm(tri-center[:,None],axis=2).max(1);shifts=list(guard.trial_shifts)
        tree=cKDTree(np.concatenate([center+H@shift for shift in shifts]));nf=len(self.faces)
        lists=tree.query_ball_point(center,radius+radius.max()+guard.skin)
        count=sum(map(len,lists))
        if count>guard.max_candidates:raise ValueError('Embedded triangle candidate budget exceeded')
        self._face_candidates={}
        for i,neighbors in enumerate(lists):
            candidates=[]
            for index in neighbors:
                image,j=divmod(index,nf);shift=tuple(shifts[image])
                if any(guard.adjacent(int(k),j,shift) for k in self.faces[i]):continue
                if surface_patch.separation_bound(tri[i],tri[j]+H@shift)>=guard.skin:continue
                candidates.append((j,shift))
            self._face_candidates[i]=candidates
        self._candidate_build=guard.neighbor_builds

    def resolved(self,ids,shift,points,distance,point_candidates,x,H,shifts):
        # Called by the existing collision guard for each nonlocal active EE.
        self._candidates();edge=set(map(int,ids[:2]));source_faces=[i for i,f in enumerate(self.faces) if edge.issubset(set(map(int,f)))]
        opposing=set(map(int,ids[2:]));target_faces=[i for i,f in enumerate(self.faces) if opposing.issubset(set(map(int,f)))]
        checked=False
        for face in source_faces:
            candidates=self._face_candidates.get(face,[])
            if not candidates:continue
            cf=np.array([self.faces[j] for j,_ in candidates]);cs=[s for _,s in candidates]
            for group in surface_patch.components(cf,cs,self.X,self.L):
                keys=sorted(set(candidates[k] for k in group))
                if not any(j in target_faces and tuple(s)==tuple(shift) for j,s in keys):continue
                self._certify(face,keys,point_candidates);checked=True
        if checked:return 'material_surface_integral'
        return self._base_coverage.resolved(ids,shift,points,distance,point_candidates,x,H,shifts)

    def _certify(self,face,keys,point_candidates):
        key=(face,tuple(keys))
        if key in self._certificates:return
        source=self._x[self.faces[face]];targets=np.array([self._x[self.faces[j]]+self._H@shift for j,shift in keys])
        # Shared mesh nodes share reaction columns; distinct images do not.
        identities=[(int(node),*shift) for j,shift in keys for node in self.faces[j]]
        unique=sorted(set(identities));mapping=np.array([unique.index(item) for item in identities]).reshape(-1,3)
        tri=self.X[self.faces[face]];A=np.linalg.norm(np.cross(tri[1]-tri[0],tri[2]-tri[0]))/2
        try:reference=surface_patch.integrate(source,targets,A,kn=.5*self.kn,thickness=self.thickness,tolerance=self.quadrature_tolerance*.25,vertex_map=mapping)
        except surface_patch.IntegrationRefinement as exc:raise SurfaceResolutionError(str(exc)) from exc
        if face in self.face_points:nodes,B,w=self.face_points[face]
        else:nodes=self.faces[face];B=np.eye(3);w=np.full(3,A/3)
        values,gaps,selected=surface_patch.field(B,source,targets,.5*self.kn,self.thickness,mapping);current=w@values;exact=reference['value']
        force_scale=max(float(np.linalg.norm(exact[1:10].reshape(3,3).sum(0))),1e-16)
        energy_error=abs(current[0]-exact[0])/max(abs(exact[0]),1e-18)
        force_error=float(np.max(abs(current[1:]-exact[1:])))/force_scale
        if max(energy_error,force_error)>self.quadrature_tolerance:
            error=SurfaceResolutionError('Embedded material quadrature requires inactive-checkpoint replay')
            error.feature=dict(kind='material_quadrature',requires_quadrature_refinement=True,face=int(face),
                               normal_energy_relative_error=float(energy_error),normal_force_relative_error=force_error,
                               rule=dict(bary=reference['bary'].tolist(),weights=reference['weights'].tolist()))
            raise error
        for node,gap,selected_face in zip(nodes,gaps,selected):
            if gap>=self.thickness:continue
            target,shift=keys[int(selected_face)]
            admissible=point_candidates.get(int(node),[])
            if not any(v[1][2]==target and tuple(v[3])==tuple(shift) for v in admissible):
                raise SurfaceResolutionError('Adaptive normal patch differs from admissible material contact selection')
        self._certificates[key]=dict(energy_error=float(energy_error),force_error=force_error)
