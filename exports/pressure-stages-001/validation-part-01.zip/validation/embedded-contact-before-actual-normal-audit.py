"""Material surface quadrature embedded in the existing guarded friction law.

Virtual points have no mass/DOFs. Forces and stiffness majorants are pulled
back by the transpose of their exact material interpolation. Rule changes
require replay from a known inactive initial state, never history interpolation.
"""
from copy import deepcopy
import numpy as np
from scipy.sparse import csr_matrix
from scipy.spatial import cKDTree
from .area_contact import AreaContact,SurfaceResolutionError
from .explicit_periodic import Periodic
from . import surface_patch


class EmbeddedContact:
    def __init__(self,X,t,periodic,kn,mu,skin,quadrature_rules=None,quadrature_tolerance=.001,**kwargs):
        self.X=np.array(X,copy=True);self.periodic=periodic;self.rules=deepcopy(quadrature_rules or {});self.quadrature_tolerance=quadrature_tolerance
        kwargs.pop('quadrature_mode',None)
        # Discover the same physical/cell-cut faces as the existing backend.
        base=AreaContact(X,t,periodic,kn,mu,skin,quadrature_mode='material',**kwargs)
        faces=base.faces;N=len(X);rows=list(range(N));cols=list(range(N));values=[1.]*N
        added=[];virtual_faces=[];areas=base.integration_area0.copy();self.face_points={}
        for key,rule in sorted(self.rules.items(),key=lambda item:int(item[0])):
            face=int(key);B=np.asarray(rule['bary'],float);weights=np.asarray(rule['weights'],float)
            ids=faces[face];tri=X[ids];A=np.linalg.norm(np.cross(tri[1]-tri[0],tri[2]-tri[0]))/2
            if B.ndim!=2 or B.shape[1]!=3 or weights.shape!=(len(B),) or np.min(B)<-1e-12 or np.max(abs(B.sum(1)-1))>1e-12 or np.any(weights<=0) or abs(weights.sum()-A)>max(1e-12,A*1e-10):raise ValueError('Invalid full-reference-face quadrature rule')
            areas[ids]-=A/3;nodes=[]
            for bary,w in zip(B,weights):
                node=N+len(added);added.append((bary@tri,float(w)));virtual_faces.append(face);nodes.append(node)
                rows.extend([node]*3);cols.extend(ids);values.extend(bary)
            self.face_points[face]=(np.asarray(nodes),B,weights)
        if np.min(areas)<-1e-10:raise ValueError('Negative residual nodal integration area')
        self.P=csr_matrix((values,(rows,cols)),shape=(N+len(added),N));augX=self.P@X
        self.inner=AreaContact(augX,t,Periodic(augX,periodic.L),kn,mu,skin,quadrature_mode='material',**kwargs)
        guard=self.inner.guard;guard.node_area0[:N]=np.maximum(areas,0.)
        if added:guard.node_area0[N:]=np.array([p[1] for p in added])
        self.inner.quadrature_weights=guard.node_area0.copy();guard.nodes=np.r_[base.nodes,np.arange(N,len(augX))]
        original_adjacent=guard.adjacent
        def adjacent(node,face,shift):
            if node<N:return original_adjacent(node,face,shift)
            source_face=faces[virtual_faces[node-N]]
            return any(original_adjacent(int(k),face,shift) for k in source_face)
        guard.adjacent=adjacent
        for node,face in enumerate(virtual_faces,N):
            self.inner.peers[node]=set(map(int,faces[face]))
            if self.inner.material_neighborhood is not None:
                self.inner.material_neighborhood.components[node]=self.inner.material_neighborhood.components[faces[face,0]]
        self.nodes=base.nodes;self.faces=faces;self.node_area0=base.node_area0.copy();self.quadrature_mode='embedded'
        self._base_coverage=self.inner.edge_coverage
        self.inner.edge_coverage=self
        self._candidate_build=-1

    def __getattr__(self,name):return getattr(self.inner,name)
    @property
    def history(self):return self.inner.history
    @history.setter
    def history(self,value):self.inner.history=value
    @property
    def capture_audit(self):return self.inner.capture_audit
    @capture_audit.setter
    def capture_audit(self,value):self.inner.capture_audit=value
    @property
    def integration_area0(self):return np.asarray(self.P.T@self.inner.integration_area0).ravel()
    def edge_stiffness_diagonal(self):return np.asarray(self.P.T@self.inner.edge_stiffness_diagonal()).ravel()
    def accept_geometry(self,x,H):self.inner.accept_geometry(self.P@x,H)
    def replay_force_state(self,x,velocity,H):
        self._certificates={};self._requests={};self._base_coverage.cache={};self._x=x;self._H=H
        response=self.inner.replay_force_state(self.P@x,self.P@velocity,H)
        return self._collapse(response)
    def _collapse(self,response):return np.asarray(self.P.T@response[0]),response[1],response[2],response[3]
    def evaluate(self,x,velocity,H,Hdot,dt):
        self._certificates={};self._requests={};self._base_coverage.cache={};self._x=x;self._H=H
        try:response=self.inner.evaluate(self.P@x,self.P@velocity,H,Hdot,dt)
        except (ValueError,RuntimeError):
            if self._requests:self._raise_refinement()
            raise
        if self._requests:self._raise_refinement()
        return self._collapse(response)
    def _raise_refinement(self):
        error=SurfaceResolutionError('Embedded material quadrature requires inactive-checkpoint replay')
        error.feature=dict(kind='material_quadrature',requires_quadrature_refinement=True,rules=self._requests)
        raise error
    def update_topology(self,t):self.inner.update_topology(t)

    def _candidates(self):
        guard=self.inner.guard
        if self._candidate_build==guard.neighbor_builds:return
        # Same Verlet skin and motion rebuild schedule as the guarded search.
        x=self._x;H=self._H;tri=x[self.faces];center=tri.mean(1)
        radius=np.linalg.norm(tri-center[:,None],axis=2).max(1);shifts=list(guard.trial_shifts)
        tree=cKDTree(np.concatenate([center+H@shift for shift in shifts]));nf=len(self.faces)
        lists=tree.query_ball_point(center,radius+radius.max()+guard.skin)
        count=sum(map(len,lists))
        if count>guard.max_candidates:raise ValueError('Embedded triangle candidate budget exceeded')
        self._face_candidates={}
        for i,neighbors in enumerate(lists):
            candidates=[]
            for index in neighbors:
                image,j=divmod(index,nf);shift=tuple(shifts[image])
                if any(guard.adjacent(int(k),j,shift) for k in self.faces[i]):continue
                if surface_patch.separation_bound(tri[i],tri[j]+H@shift)>=guard.skin:continue
                candidates.append((j,shift))
            self._face_candidates[i]=candidates
        self._candidate_build=guard.neighbor_builds

    def resolved(self,ids,shift,points,distance,point_candidates,x,H,shifts):
        # Called by the existing collision guard for each nonlocal active EE.
        self._candidates();edge=set(map(int,ids[:2]));source_faces=[i for i,f in enumerate(self.faces) if edge.issubset(set(map(int,f)))]
        opposing=set(map(int,ids[2:]));target_faces=[i for i,f in enumerate(self.faces) if opposing.issubset(set(map(int,f)))]
        checked=False
        for face in source_faces:
            candidates=self._face_candidates.get(face,[])
            if not candidates:continue
            keys=sorted(set(candidates));cf=np.array([self.faces[j] for j,_ in keys]);cs=[s for _,s in keys]
            if not any(j in target_faces and tuple(s)==tuple(shift) for j,s in keys):continue
            groups=surface_patch.components(cf,cs,self.X,self.L)
            self._certify(face,keys,groups,point_candidates);checked=True
        if checked:return 'material_surface_integral'
        return self._base_coverage.resolved(ids,shift,points,distance,point_candidates,x,H,shifts)

    def _certify(self,face,keys,groups,point_candidates):
        key=(face,tuple(keys))
        if key in self._certificates:return
        source=self._x[self.faces[face]];targets=np.array([self._x[self.faces[j]]+self._H@shift for j,shift in keys])
        # Shared mesh nodes share reaction columns; distinct images do not.
        identities=[(int(self.periodic.classes[node]),*np.rint((self.X[node]+self.L*np.asarray(shift))/(self.L*1e-10)).astype(np.int64)) for j,shift in keys for node in self.faces[j]]
        unique=sorted(set(identities));mapping=np.array([unique.index(item) for item in identities]).reshape(-1,3)
        tri=self.X[self.faces[face]];A=np.linalg.norm(np.cross(tri[1]-tri[0],tri[2]-tri[0]))/2
        try:reference=surface_patch.integrate(source,targets,A,kn=.5*self.kn,thickness=self.thickness,tolerance=self.quadrature_tolerance*.25,vertex_map=mapping,groups=groups)
        except surface_patch.IntegrationRefinement as exc:raise SurfaceResolutionError(str(exc)) from exc
        if face in self.face_points:nodes,B,w=self.face_points[face]
        else:nodes=self.faces[face];B=np.eye(3);w=np.full(3,A/3)
        values,gaps,selections=surface_patch.grouped_field(B,source,targets,groups,.5*self.kn,self.thickness,mapping);current=w@values;exact=reference['value']
        force_scale=max(float(np.linalg.norm(exact[1:10].reshape(3,3).sum(0))),float(np.linalg.norm(exact[10:].reshape(-1,3),axis=1).sum()),1e-16)
        energy_error=abs(current[0]-exact[0])/max(abs(exact[0]),1e-18)
        force_error=float(np.max(abs(current[1:]-exact[1:])))/force_scale
        if max(energy_error,force_error)>self.quadrature_tolerance:
            self._requests[str(face)]=dict(bary=reference['bary'].tolist(),weights=reference['weights'].tolist(),normal_energy_relative_error=float(energy_error),normal_force_relative_error=force_error)
        else:
            from .contact_geometry import closest_triangle
            missing_energy=0.;missing_force=0.
            for group,selected in zip(groups,selections):
                group_keys={keys[k] for k in group}
                for node,bary,weight,selected_face in zip(nodes,B,w,selected):
                    point=bary@source;projection,_=closest_triangle(point,targets[int(selected_face)]);offset=point-projection;gap=np.linalg.norm(offset)
                    if gap>=self.thickness:continue
                    tolerance=max(self.L*1e-10,4*np.sqrt(2*gap*128*np.finfo(float).eps*max(1.,self.L)))
                    admissible=point_candidates.get(int(node),[])
                    if not any((v[1][2],tuple(v[3])) in group_keys and np.linalg.norm(v[-1]-offset)<=tolerance for v in admissible):
                        from .barrier_contact import barrier
                        E,Fn,_=barrier(gap,.5*self.kn,self.thickness)
                        missing_energy+=weight*E;missing_force+=weight*Fn
            if missing_energy>1e-18 or missing_force>1e-16:
                raise SurfaceResolutionError('Adaptive normal patch differs from admissible material contact selection')
        self._certificates[key]=dict(energy_error=float(energy_error),force_error=force_error)


def reinitialize_inactive(old,new,x,velocity,H,contact_free_prefix):
    """A topology change may reset quadrature only before ANY contact history."""
    if not contact_free_prefix or old.history or old.minimum_separation<old.thickness:
        raise ValueError('Embedded remesh requires a certified contact-free prefix; active-history reset prohibited')
    response=new.evaluate(x,velocity,H,H*0,0.)
    if response[2] or response[-1]['normal_energy']+response[-1]['tangent_energy']>1e-16:
        raise ValueError('Embedded remesh creates active initial quadrature')
    return response
