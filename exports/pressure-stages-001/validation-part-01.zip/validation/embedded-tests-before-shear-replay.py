from copy import deepcopy
import numpy as np
import pytest
from packing_fem.embedded_contact import EmbeddedContact
from packing_fem.explicit_periodic import Periodic
from packing_fem.triangle_quadrature import RULES
from packing_fem.barrier_contact import barrier
from tools.verify_plane_contact import fixture


def setup(slip=0.,refined=True):
    X,t,x,H,upper=fixture(1,.015,0.);p=Periodic(X,1.)
    old=EmbeddedContact(X,t,p,20.,.3,.1,thickness=.02)
    rules={}
    if refined:
        for i,face in enumerate(old.faces):
            if not np.all(np.isclose(X[face,2],.6)):continue
            tri=X[face];A=np.linalg.norm(np.cross(tri[1]-tri[0],tri[2]-tri[0]))/2
            B,w=RULES[8];rules[str(i)]=dict(bary=B.tolist(),weights=(A*w).tolist())
    contact=EmbeddedContact(X,t,p,20.,.3,.1,thickness=.02,quadrature_rules=rules)
    return X,t,x,H,upper,contact


@pytest.mark.parametrize('refined',[False,True])
def test_embedded_plane_area_force_and_virtual_work(refined):
    X,t,x,H,upper,c=setup(refined=refined)
    f,extra,hist,r=c.evaluate(x,x*0,H,H*0,0.)
    E,F,_=barrier(.015,20.,.02)
    assert r['normal_energy']==pytest.approx(E,rel=1e-8)
    assert f[upper,2].sum()==pytest.approx(F,rel=1e-8)
    np.testing.assert_allclose(f.sum(0),0,atol=1e-12)
    assert len(c.edge_stiffness_diagonal())==len(X)
    assert c.integration_area0.sum()==pytest.approx(c.node_area0.sum())


@pytest.mark.parametrize('slip',[.0001,.01])
def test_embedded_friction_preserves_committed_and_applied_states(slip):
    X,t,x,H,upper,c=setup()
    before=c.evaluate(x,x*0,H,H*0,0.);c.history=before[2];c.accept_geometry(x,H)
    original=x.copy();initial_cell=H.copy()
    for displacement in np.linspace(0,slip,9)[1:]:
        x=original.copy();x[upper,0]+=displacement;H=initial_cell.copy();H[0,2]+=displacement
        result=c.evaluate(x,x*0,H,H*0,.001/8);c.history=result[2];c.accept_geometry(x,H)
    saved=deepcopy(c.history);replay=c.replay_force_state(x,x*0,H)
    np.testing.assert_allclose(result[0],replay[0],atol=1e-12)
    assert result[-1]['max_coulomb_ratio']<=.3+1e-12
    assert result[-1]['tangent_energy']>0
    for key in saved:np.testing.assert_array_equal(c.history[key]['plastic'],saved[key]['plastic'])


def test_invalid_partial_face_quadrature_is_rejected():
    X,t,x,H,upper,c=setup(refined=False)
    with pytest.raises(ValueError,match='quadrature'):
        EmbeddedContact(X,t,Periodic(X,1.),20.,.3,.1,thickness=.02,quadrature_rules={'0':dict(bary=[[1/3]*3],weights=[1.])})


def test_nonmatching_periodic_mesh_refines_only_by_inactive_replay():
    from packing_fem.area_contact import SurfaceResolutionError
    rules={};requests=0
    for attempt in range(12):
        X,t,_,_,upper=fixture(1,.015,.25)
        c=EmbeddedContact(X,t,Periodic(X,1.),20.,.3,.1,thickness=.02,quadrature_rules=rules)
        try:
            for gap in np.linspace(.025,.015,9):
                _,_,x,H,_=fixture(1,float(gap),.25)
                value=c.evaluate(x,x*0,H,H*0,0.)
                if gap==.025:assert not value[2]
                c.history=value[2];c.accept_geometry(x,H)
            break
        except SurfaceResolutionError as error:
            feature=getattr(error,'feature',None)
            assert feature and feature.get('requires_quadrature_refinement'),str(error)
            rules.update(feature['rules']);requests+=1
    else:raise AssertionError('Replay budget exhausted')
    assert requests>0
    E,F,_=barrier(.015,20.,.02)
    assert value[-1]['normal_energy']==pytest.approx(E,rel=1e-3)
    assert value[0][upper,2].sum()==pytest.approx(F,rel=1e-3)
