"""Closest connected surface patch integration in a specified periodic image.

The caller owns image enumeration, topology exclusions and history. Facets of a
patch locate one closest surface; their potentials are never added together.
"""
import numpy as np
from .triangle_quadrature import density_batch,split,RULES


class IntegrationRefinement(ValueError):
    pass


def separation_bound(source,target):
    """Conservative support-interval distances along separating axes."""
    es=np.roll(source,-1,axis=0)-source;et=np.roll(target,-1,axis=0)-target
    ns=np.cross(es[0],es[1]);nt=np.cross(et[0],et[1])
    axes=np.r_[ns[None],nt[None],np.cross(es[:,None,:],et[None,:,:]).reshape(-1,3),np.cross(ns,es),np.cross(nt,et)]
    norms=np.linalg.norm(axes,axis=1);axes=axes[norms>1e-25]/norms[norms>1e-25,None]
    if not len(axes):raise ValueError('Degenerate contact surface')
    ps=source@axes.T;pt=target@axes.T
    gap=np.maximum(ps.min(0)-pt.max(0),pt.min(0)-ps.max(0))
    pad=128*np.finfo(float).eps*max(1.,float(abs(source).max()),float(abs(target).max()))
    return max(0.,float(gap.max())-pad)


def field(bary,source,targets,kn,thickness,vertex_map=None):
    bary=np.asarray(bary);targets=np.asarray(targets)
    results=[density_batch(bary,source,target,kn,thickness) for target in targets]
    distances=np.array([r[1] for r in results]);selected=np.argmin(distances,axis=0)
    count=len(bary)
    if vertex_map is None:vertex_map=np.arange(3*len(targets)).reshape(-1,3)
    values=np.zeros((count,10+3*(int(np.max(vertex_map))+1)))
    for k,(density,gaps) in enumerate(results):
        take=selected==k;values[take,:10]=density[take,:10]
        for j,node in enumerate(vertex_map[k]):values[take,10+3*node:13+3*node]+=density[take,10+3*j:13+3*j]
    # Distinct equally closest points are not silently turned into one plane.
    for k,(_,gaps) in enumerate(results):
        same=abs(gaps-distances.min(0))<=128*np.finfo(float).eps*max(1.,float(abs(source).max()))
        other=same&(selected!=k)&(gaps<thickness)
        if np.any(other):
            from .contact_geometry import closest_triangle
            for i in np.flatnonzero(other):
                point=bary[i]@source
                a=closest_triangle(point,targets[k])[0];b=closest_triangle(point,targets[selected[i]])[0]
                if np.linalg.norm(a-b)>max(1e-10,1e-6*gaps[i]):raise IntegrationRefinement('Distinct tied closest patch projections require subgradient integration')
    return values,distances.min(0),selected


def integrate(source,targets,reference_area,kn=20.,thickness=.02,tolerance=1e-3,max_depth=28,max_cells=20000,vertex_map=None):
    """Adaptive reference-area rule, including points on inactive subdomains."""
    source=np.asarray(source);targets=np.asarray(targets)
    if vertex_map is None:vertex_map=np.arange(3*len(targets)).reshape(-1,3)
    size=10+3*(int(np.max(vertex_map))+1)
    absolute=np.r_[1e-18,np.full(size-1,1e-16)];inactive=[];cells=0;evaluations=0
    def area(B):return reference_area*abs(float(np.linalg.det(B)))
    def rule(B,order):
        nonlocal evaluations
        nodes,w=RULES[order];bary=nodes@B
        values,gaps,_=field(bary,source,targets,kn,thickness,vertex_map);evaluations+=len(bary)
        return area(B)*(w@values),bary,area(B)*w,gaps
    def build(B,depth):
        nonlocal cells
        cells+=1;bound=min(separation_bound(B@source,target) for target in targets)
        if bound>=thickness:
            inactive.append(B);return None
        coarse,_,_,gaps=rule(B,4)
        _,vertex_gaps,_=field(B,source,targets,kn,thickness,vertex_map)
        children=split(B,vertex_gaps);fine=np.zeros(size);samples=[];minimum=min(gaps)
        for child in children:
            value,bary,w,distances=rule(child,8);fine+=value;samples.append((bary,w));minimum=min(minimum,min(distances))
        resolved=bound>0 and fine[0]>0 and minimum<=2*bound
        if resolved:error=abs(fine-coarse)
        elif bound>0:
            from .barrier_contact import barrier
            E,F,_=barrier(bound,kn,thickness);error=area(B)*np.r_[E,np.full(size-1,F)]+abs(fine)
        else:error=np.full(size,np.inf)
        return dict(value=fine,error=error,children=children,samples=samples,depth=depth)
    first=build(np.eye(3),0);leaves=[] if first is None else [first]
    while leaves:
        total=sum((leaf['value'] for leaf in leaves),np.zeros(size));errors=np.array([leaf['error'] for leaf in leaves])
        budget=absolute+tolerance*abs(total)
        if np.all(errors.sum(0)<=budget):break
        k=int(np.argmax(np.max(errors/budget,axis=1)));leaf=leaves.pop(k)
        if cells>=max_cells or leaf['depth']>=max_depth:raise IntegrationRefinement('Surface patch quadrature subdivision limit')
        for child in leaf['children']:
            new=build(child,leaf['depth']+1)
            if new is not None:leaves.append(new)
    else:total=np.zeros(size)
    points=[];weights=[]
    for leaf in leaves:
        for bary,w in leaf['samples']:points.extend(bary);weights.extend(w)
    for B in inactive:
        nodes,w=RULES[4];points.extend(nodes@B);weights.extend(area(B)*w)
    return dict(value=total,bary=np.asarray(points).reshape(-1,3),weights=np.asarray(weights),cells=cells,evaluations=evaluations,
                area_error=abs(sum(weights)-reference_area))


def components(faces,shifts,X,L):
    """Connected facets in actual reference images, not merely class IDs."""
    groups=[]
    for i,(face,shift) in enumerate(zip(faces,shifts)):
        vertices=set(map(tuple,np.rint((X[face]+L*np.asarray(shift))/(L*1e-10)).astype(np.int64)))
        linked=[j for j,(keys,_) in enumerate(groups) if keys&vertices];members=[i]
        for j in reversed(linked):
            keys,old=groups.pop(j);vertices|=keys;members.extend(old)
        groups.append((vertices,members))
    return [sorted(members) for _,members in groups]
