from pathlib import Path
import json
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import splu,lsmr
from tools.audit_rigid_compaction import load
from packing_fem.rigid_inclusion import make_periodic,make_contact
from packing_fem.explicit_material import geometry
from packing_fem.implicit_material import evaluate
root=Path('results/rigid-inclusion-001');run=root/'compression-001';old=load(run/'state-0002.npz');path=run/'iterate-trace/iterate-1794285260362064557-0040.npz';trace=load(path);q=trace['q'];c=json.loads((run/'config.json').read_text())
assert all(np.array_equal(trace[k],old[k]) for k in ['X','t','b','ep']);np.testing.assert_array_equal(trace['oldq'],old['q']);p=make_periodic(old['X'],c['length_mm'],c);contact=make_contact(old['X'],old['t'],p,c);inverse=np.linalg.inv(geometry(old['x'],old['t'])[2])
def values(v,tangent=False):
    _,gm,Km,_=evaluate(p.positions(v),old['t'],old['b'],old['ep'],inverse,old['V0'],dict(c,implicit_project_material_tangent=False),tangent,parent=old['parent']);_,gc,Kc,_=contact.evaluate_coupled(v,old['q'],tangent)
    return (np.asarray(p.A.T@gm.ravel()).ravel()+gc)[:p.nmicro],None if not tangent else (p.A.T@Km@p.A+Kc)[:p.nmicro,:p.nmicro].tocsc()
g,J=values(q,True);merit=.5*g@g;gradient=J.T@g;diagonal=np.maximum(abs(J.diagonal()),1e-6);newton=splu(J+diags(diagonal*c['implicit_regularization']),permc_spec='COLAMD').solve(-g);columns=1/np.sqrt(np.maximum(np.asarray(J.power(2).sum(axis=0)).ravel(),1e-12));least=columns*lsmr(J@diags(columns),-g,damp=.1,atol=1e-4,btol=1e-4,maxiter=500)[0];rows=[]
for name,base in [('newton',newton),('lsmr',least)]:
    for cap in [False,True]:
        dq=np.zeros(p.ndof);dq[:p.nmicro]=base
        if cap:
            for ids,limit in [(p.rigid_dofs[:3],.1),(p.rigid_dofs[3:],.05*p.rigid_radius)]:
                norm=np.linalg.norm(dq[ids]);dq[ids]*=min(1.,limit/max(norm,1e-30))
        slope=float(gradient@dq[:p.nmicro]);bound=contact.ccd(q,dq);alpha=1. if bound>=1 else .9*bound
        row=dict(direction=name,capped=cap,slope=slope,ccd_bound=bound,ccd_horizon=contact.last_ccd_horizon,body_step_mm=float(abs(dq[:p.body_nmicro]).max()),rigid_translation_mm=float(np.linalg.norm(dq[p.rigid_dofs[:3]])),rigid_rotation_rad=float(np.linalg.norm(dq[p.rigid_dofs[3:]])/p.rigid_radius))
        if slope<0:
            for _ in range(12):
                try:
                    candidate=q+alpha*dq;cg,_=values(candidate)
                    if .5*cg@cg<=merit+1e-4*alpha*slope:
                        row.update(alpha=alpha,maximum_force_N=float(abs(cg).max()),l2_force_N=float(np.linalg.norm(cg)));break
                except (ValueError,RuntimeError):pass
                alpha*=.5
        rows.append(row);print(json.dumps(row),flush=True)
pth=root/'direction-diagnostic-003.json';assert not pth.exists();pth.write_text(json.dumps(dict(initial_maximum_force_N=float(abs(g).max()),initial_l2_force_N=float(np.linalg.norm(g)),initial_guess_only=True,accepted_solution=False,trace=str(path),candidates=rows),indent=2)+'\n')
