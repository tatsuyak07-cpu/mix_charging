from pathlib import Path
import json,numpy as np
from packing_fem.rigid_inclusion import make_periodic,make_contact
from tools.audit_rigid_compaction import load
root=Path('results/rigid-inclusion-001');out=root/'rigid-jacobian-audit-001.json';assert not out.exists();run=root/'compression-007';c=json.loads((run/'config.json').read_text());old=load(run/'state-0000.npz');path=sorted((run/'iterate-trace').glob('*.npz'))[-1];q=load(path)['q'];p=make_periodic(old['X'],c['length_mm'],c);contact=make_contact(old['X'],old['t'],p,c)
def signature():
 return set((name,tuple(item.vertex_ids(contact.edges,contact.faces))) for name in ['vv_collisions','ev_collisions','ee_collisions','fv_collisions'] for item in getattr(contact.last_normal,name))
_,g,J,_=contact.evaluate_coupled(q,old['q'],True);base=signature();rows=[]
for axis in range(6):
 direction=np.zeros(p.ndof);direction[p.rigid_dofs[axis]]=1.;analytic=J@direction
 for h in [1e-6,1e-7,1e-8]:
  gp=contact.evaluate_coupled(q+h*direction,old['q'])[1];sp=signature();gm=contact.evaluate_coupled(q-h*direction,old['q'])[1];sm=signature();fd=(gp-gm)/(2*h)
  row=dict(rigid_axis=axis,h_mm=h,relative_l2_error=float(np.linalg.norm(fd-analytic)/max(np.linalg.norm(fd),1e-30)),maximum_error_N_per_mm=float(abs(fd-analytic).max()),fd_maximum_N_per_mm=float(abs(fd).max()),changed_plus_stencils=len(base^sp),changed_minus_stencils=len(base^sm));rows.append(row);print(json.dumps(row),flush=True)
out.write_text(json.dumps(dict(source=str(path),rows=rows,passed=all(min(r['relative_l2_error'] for r in rows if r['rigid_axis']==axis)<1e-4 for axis in range(6))),indent=2)+'\n')
