from pathlib import Path
import json,time
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import lsmr
from packing_fem.rigid_inclusion import make_periodic,make_contact
from packing_fem.implicit_material import evaluate
from packing_fem.explicit_material import geometry
from tools.audit_rigid_compaction import load
root=Path('results/rigid-inclusion-001');out=root/'peak-direction-diagnostic-001.json';assert not out.exists();run=root/'compression-007';c=json.loads((run/'config.json').read_text());old=load(run/'state-0000.npz');path=sorted((run/'iterate-trace').glob('*.npz'))[-1];q=load(path)['q'];p=make_periodic(old['X'],c['length_mm'],c);contact=make_contact(old['X'],old['t'],p,c);inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);t=old['t']
def values(q,tangent=False):
 _,gm,Km,state=evaluate(p.positions(q),t,old['b'],old['ep'],inverse,old['V0'],dict(c,implicit_project_material_tangent=False),tangent,parent=old['parent'])
 _,gc,Kc,n=contact.evaluate_coupled(q,old['q'],tangent)
 solid=np.asarray(p.A.T@gm.ravel()).ravel()
 return (solid+gc)[:p.nmicro],None if not tangent else (p.A.T@Km@p.A+Kc)[:p.nmicro,:p.nmicro].tocsc(),solid,gc
g,J,solid,gc=values(q,True);maximum=float(abs(g).max());merit=.5*maximum**2;active=abs(g)>=maximum*(1-1e-12);merit_force=np.where(active,g/max(int(active.sum()),1),0.);scale=np.maximum((abs(g)/maximum)**2,.05);row_scaled=diags(scale)@J;column_scale=1/np.sqrt(np.maximum(np.asarray(row_scaled.power(2).sum(axis=0)).ravel(),1e-12));scaled=row_scaled@diags(column_scale);rows=[];best=None
peaks=[]
for index in np.argsort(abs(g))[-12:][::-1]:
 row=dict(dof=int(index),kind='rigid' if index>=p.body_nmicro else 'solid',force_N=float(g[index]),solid_N=float(solid[index]),contact_N=float(gc[index]),diagonal_N_per_mm=float(J[index,index]))
 if index<p.body_nmicro:row['point_mm']=p.positions(q)[np.flatnonzero(p.classes==index//3+1)[0]].tolist();row['axis']=int(index%3)
 peaks.append(row)
for damping in [.0001,.001,.01,.1]:
 start=time.monotonic();linear=lsmr(scaled,-scale*g,damp=damping,atol=1e-4,btol=1e-4,maxiter=1000);direction=np.zeros(p.ndof);direction[:p.nmicro]=column_scale*linear[0];slope=float((J.T@merit_force)@direction[:p.nmicro]);bound=contact.ccd(q,direction);alpha=1. if bound>=1 else .9*bound
 for _ in range(30):
  try:
   cg,_,_,_=values(q+alpha*direction);cm=.5*float(abs(cg).max())**2
   if cm<=merit+1e-4*alpha*slope:break
  except (ValueError,RuntimeError):pass
  alpha*=.5
 else:cm=float('inf')
 row=dict(damping=damping,linear_iterations=int(linear[2]),alpha=alpha,merit_before=merit,merit_after=cm,maximum_after_N=float(abs(cg).max()),l2_after_N=float(np.linalg.norm(cg)),ccd_bound=float(bound),maximum_direction_mm=float(abs(direction[:p.nmicro]).max()),wall_s=time.monotonic()-start);rows.append(row);print(json.dumps(row),flush=True)
 if best is None or cm<best[0]:best=(cm,q+alpha*direction)
np.savez_compressed(root/'peak-direction-candidate-001.npz',q=best[1],X=old['X'],t=t,oldq=old['q'],b=old['b'],ep=old['ep'])
out.write_text(json.dumps(dict(source=str(path),initial_maximum_N=maximum,initial_l2_N=float(np.linalg.norm(g)),initial_guess_only=True,peaks=peaks,rows=rows),indent=2)+'\n')
