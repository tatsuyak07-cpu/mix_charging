from pathlib import Path
import csv,json,shutil,hashlib
import numpy as np
from packing_fem.rigid_inclusion import make_periodic,cylinder_surface
from tools.audit_rigid_compaction import load
from tools.export_rigid_compaction import sections
from tools.export_pressure_stages import render
root=Path('results/rigid-inclusion-001');out=Path('exports/rigid-inclusion-progress-001');out.mkdir(exist_ok=False)
c=json.loads((root/'compression-002/config.json').read_text());initial=load(root/'compression-001/state-0000.npz');path=root/'compression-002/state-0001.npz';loaded=load(path);local,faces=cylinder_surface(c);p=make_periodic(loaded['X'],c['length_mm'],c);center,(R,_,_)=p.pose(loaded['q'])
render(out/'compression-00953.png',loaded,'Floating D4 x H4 mm rigid cylinder:16-grain prototype\nAccepted9.53125% compression; matrix porosity34.2357%',c['length_mm'],footer='Actual FEM mesh; orange = rigid; displacement scale1x\nPartial run: target10% NOT reached; mesh / increment convergence unverified',rigid_surface=(local@R.T+center,faces))
sections(initial,loaded,c,out/'pore-sections.png');shutil.copy2(path,out/'accepted-state.npz');shutil.copy2(root/'compression-002/config.json',out/'config.json')
for name in ['audit-prefix-001.json','audit-prefix-002.json','curved-cache-comparison.json','tests-007.log','input/placement.json']:shutil.copy2(root/name,out/Path(name).name)
with (root/'compression-001/history.csv').open() as f:a=[r for r in csv.DictReader(f) if int(r['step'])<=2]
with (root/'compression-002/history.csv').open() as f:b=[r for r in csv.DictReader(f) if int(r['step'])<=1]
rows=[]
for name,group in [('compression-001',a),('compression-002',b)]:
 for r in group:r.update(source_run=name,source_step=r['step']);r['step']=len(rows)+1;rows.append(r)
with (out/'history.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
with np.load(root/'compression-001/state-0002.npz') as a,np.load(root/'compression-002/state-0000.npz') as b:assert set(a.files)==set(b.files) and all(np.array_equal(a[k],b[k]) for k in a.files)
(out/'provenance.json').write_text(json.dumps(dict(exact_restart_check_passed=True,checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),selected_prefix=['compression-001:1-2','compression-002:1'],target_reached=False,wall_time='Per-source-run wall_s; preparation of an initial guess outside selected prefixes is excluded.'),indent=2)+'\n')
(out/'README.md').write_text('''# 浮遊剛体円柱：途中結果\n\n直径4mm・高さ4mmの剛体と16粒子の数値結合試験。最終指定の20x20mm円柱／100mmセルとは区別します。\n初期充填層空隙率40.4057%から、9.53125%軸圧縮で34.2357%へ収束しました。\n両横周期寸法24.140718mmを固定し、剛体の並進・回転は自由です。\n剛体接触9項、最大自由力残差0.00480139N。各軸の剛体力とトルク／半径も0.005N未満です。\n\n**工程3の目標である空隙率10%には未到達です。計算を継続中です。**\n[実メッシュPNG](compression-00953.png)・[剛体中心断面](pore-sections.png)・[CSV](history.csv)・[保存状態](accepted-state.npz)・[独立監査](audit-prefix-002.json)・[79テスト](tests-007.log)・[報告](../../docs/rigid-inclusion-development.md)。\n\n剛体の体積を除いた領域を分母とする空隙率を主指標とし、セル全体の値を別に併記しています。\nCSV時間は各元試行内の時間で、経路外の初期推定準備費用は含みません。\n単一標本で、メッシュ・増分・円柱分割収束と剛体なしとの定量比較は未実施です。\n''')
print(out,flush=True)
