from pathlib import Path
import json,time
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import lsmr
from packing_fem.rigid_inclusion import make_periodic,make_contact
from packing_fem.implicit_material import evaluate
from packing_fem.explicit_material import geometry
from tools.audit_rigid_compaction import load
root=Path('results/rigid-inclusion-001');out=root/'lsmr-direction-diagnostic-001.json';assert not out.exists()
run=root/'compression-005';c=json.loads((run/'config.json').read_text());old=load(run/'state-0000.npz');path=sorted((run/'iterate-trace').glob('*.npz'))[-1];trial=load(path);q=trial['q'];p=make_periodic(old['X'],c['length_mm'],c);contact=make_contact(old['X'],old['t'],p,c);inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);t=old['t']
def values(q,tangent=False):
 _,gm,Km,state=evaluate(p.positions(q),t,old['b'],old['ep'],inverse,old['V0'],dict(c,implicit_project_material_tangent=False),tangent,parent=old['parent'])
 _,gc,Kc,n=contact.evaluate_coupled(q,old['q'],tangent)
 return (np.asarray(p.A.T@gm.ravel()).ravel()+gc)[:p.nmicro],None if not tangent else (p.A.T@Km@p.A+Kc)[:p.nmicro,:p.nmicro].tocsc()
g,J=values(q,True);merit=.5*float(g@g);column_scale=1/np.sqrt(np.maximum(np.asarray(J.power(2).sum(axis=0)).ravel(),1e-12));scaled=J@diags(column_scale);rows=[];best=None
for damping in [.0001,.001,.01]:
 start=time.monotonic();linear=lsmr(scaled,-g,damp=damping,atol=1e-5,btol=1e-5,maxiter=1000);direction=np.zeros(p.ndof);direction[:p.nmicro]=column_scale*linear[0];slope=float((J.T@g)@direction[:p.nmicro]);bound=contact.ccd(q,direction);alpha=1. if bound>=1 else .9*bound
 for _ in range(30):
  try:
   cg,_=values(q+alpha*direction);cm=.5*float(cg@cg)
   if cm<=merit+1e-4*alpha*slope:break
  except (ValueError,RuntimeError):pass
  alpha*=.5
 else:cm=float('inf')
 row=dict(damping=damping,linear_iterations=int(linear[2]),alpha=alpha,merit_before=merit,merit_after=cm,maximum_after_N=float(abs(cg).max()),l2_after_N=float(np.linalg.norm(cg)),wall_s=time.monotonic()-start);rows.append(row);print(json.dumps(row),flush=True)
 if best is None or cm<best[0]:best=(cm,q+alpha*direction)
np.savez_compressed(root/'lsmr-direction-candidate-001.npz',q=best[1],X=old['X'],t=t,oldq=old['q'],b=old['b'],ep=old['ep'])
out.write_text(json.dumps(dict(source=str(path),initial_maximum_N=float(abs(g).max()),initial_l2_N=float(np.linalg.norm(g)),initial_guess_only=True,rows=rows),indent=2)+'\n')
