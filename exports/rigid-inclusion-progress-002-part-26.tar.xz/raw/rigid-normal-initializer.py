from pathlib import Path
import json,time,numpy as np
import ipctk as ipc
from packing_fem.rigid_inclusion import make_periodic,make_contact
from packing_fem.implicit_material import evaluate
from packing_fem.explicit_material import geometry
from tools.audit_rigid_compaction import load
root=Path('results/rigid-inclusion-001');out=root/'rigid-normal-initializer-001.json';assert not out.exists();run=root/'compression-007';c=json.loads((run/'config.json').read_text());old=load(run/'state-0000.npz');path=sorted((run/'iterate-trace').glob('*.npz'))[-1];q=load(path)['q'];p=make_periodic(old['X'],c['length_mm'],c);contact=make_contact(old['X'],old['t'],p,c);ids=p.rigid_dofs;rows=[]
for iteration in range(50):
 x=contact.positions(q);n=contact.collisions(x);energy=float(contact.barrier(n,contact.mesh,x));full=contact.barrier.gradient(n,contact.mesh,x);R=contact.jacobian(q)[:,ids];g=np.asarray(R.T@full).ravel();row=dict(iteration=iteration,normal_barrier_Nmm=energy,rigid_normal_gradient_max_N=float(abs(g).max()));rows.append(row);print(json.dumps(row),flush=True)
 if abs(g).max()<1e-8:break
 H=contact.barrier.hessian(n,contact.mesh,x,ipc.PSDProjectionMethod.CLAMP);block=(R.T@H@R).toarray();diagonal=np.maximum(abs(block.diagonal()),1e-6);step=np.linalg.lstsq(block+np.diag(diagonal*1e-5),-g,rcond=1e-12)[0]
 if not np.all(np.isfinite(step)) or g@step>=0:step=-g/diagonal
 direction=np.zeros(p.ndof);direction[ids]=step;bound=contact.ccd(q,direction);alpha=1. if bound>=1 else .9*bound
 for _ in range(30):
  trial=q+alpha*direction;x=contact.positions(trial);n=contact.collisions(x);value=float(contact.barrier(n,contact.mesh,x))
  if value<=energy+1e-4*alpha*(g@step):break
  alpha*=.5
 else:break
 q=trial
inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);_,gm,_,_=evaluate(p.positions(q),old['t'],old['b'],old['ep'],inverse,old['V0'],c,parent=old['parent']);_,gc,_,count=contact.evaluate_coupled(q,old['q']);force=np.asarray(p.A.T@gm.ravel()).ravel()+gc
np.savez_compressed(root/'rigid-normal-candidate-001.npz',q=q,X=old['X'],t=old['t'],oldq=old['q'],b=old['b'],ep=old['ep'])
result=dict(source=str(path),initial_guess_only=True,final_original_friction_maximum_N=float(abs(force[:p.nmicro]).max()),final_rigid_maximum_N=float(abs(force[ids]).max()),final_rigid_contacts=contact.rigid_contact_count(),rows=rows);out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
