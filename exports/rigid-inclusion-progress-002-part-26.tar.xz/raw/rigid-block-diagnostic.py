from pathlib import Path
import json,numpy as np
from packing_fem.rigid_inclusion import make_periodic,make_contact
from packing_fem.implicit_material import evaluate
from packing_fem.explicit_material import geometry
from tools.audit_rigid_compaction import load
root=Path('results/rigid-inclusion-001');out=root/'rigid-block-diagnostic-001.json';assert not out.exists();run=root/'compression-007';c=json.loads((run/'config.json').read_text());old=load(run/'state-0000.npz');path=sorted((run/'iterate-trace').glob('*.npz'))[-1];q=load(path)['q'];p=make_periodic(old['X'],c['length_mm'],c);contact=make_contact(old['X'],old['t'],p,c);inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);t=old['t']
_,gm,_,_=evaluate(p.positions(q),t,old['b'],old['ep'],inverse,old['V0'],c,parent=old['parent']);solid=np.asarray(p.A.T@gm.ravel()).ravel();_,gc,J,_=contact.evaluate_coupled(q,old['q'],True);g=(solid+gc)[:p.nmicro];ids=p.rigid_dofs;block=J[ids,:][:,ids].toarray();maximum=float(abs(g).max());merit=.5*maximum**2;rows=[];best=None
for regularization in [0.,1e-7,.001,.1]:
 direction=np.zeros(p.ndof);direction[ids]=np.linalg.lstsq(block+np.diag(np.maximum(abs(block.diagonal()),1e-6)*regularization),-g[ids],rcond=1e-12)[0];bound=contact.ccd(q,direction);alpha=1. if bound>=1 else .9*bound
 for _ in range(25):
  try:
   _,cg,_,_=contact.evaluate_coupled(q+alpha*direction,old['q']);full=(solid+cg)[:p.nmicro];cm=.5*float(abs(full).max())**2
   if cm<merit:break
  except (ValueError,RuntimeError):pass
  alpha*=.5
 else:cm=float('inf')
 row=dict(regularization=regularization,alpha=alpha,merit_before=merit,merit_after=cm,maximum_after_N=float(abs(full).max()),body_maximum_after_N=float(abs(full[:p.body_nmicro]).max()),rigid_maximum_after_N=float(abs(full[ids]).max()),l2_after_N=float(np.linalg.norm(full)),rigid_direction_mm=direction[ids].tolist());rows.append(row);print(json.dumps(row),flush=True)
 if best is None or cm<best[0]:best=(cm,q+alpha*direction)
np.savez_compressed(root/'rigid-block-candidate-001.npz',q=best[1],X=old['X'],t=t,oldq=old['q'],b=old['b'],ep=old['ep'])
out.write_text(json.dumps(dict(source=str(path),initial_maximum_N=maximum,initial_body_maximum_N=float(abs(g[:p.body_nmicro]).max()),initial_guess_only=True,rows=rows),indent=2)+'\n')
