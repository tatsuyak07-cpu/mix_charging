"""Small-memory Anderson proposal; callers must safeguard physical admissibility."""
import numpy as np


def anderson_candidate(outputs,residuals,scale):
    if len(outputs)<2:return None
    R=np.column_stack(residuals)*np.asarray(scale)[:,None]
    differences=R[:,:-1]-R[:,-1:]
    weights=np.linalg.lstsq(differences,-R[:,-1],rcond=1e-10)[0]
    weights=np.r_[weights,1-weights.sum()]
    if not np.all(np.isfinite(weights)) or abs(weights).sum()>10:return None
    return np.column_stack(outputs)@weights
