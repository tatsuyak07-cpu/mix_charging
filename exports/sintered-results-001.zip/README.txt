Source calculation: results/sintered-baseline-03
Mesh images: undeformed 1 mm C3D8 mesh, 400706 elements.
Mesh convergence remains unverified.
