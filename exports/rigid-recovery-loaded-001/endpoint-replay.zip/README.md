# 保存終点の独立再計算用データ

16粒子D10 mm・ネック2 mm、周期セル24.1407 mm角、自由6DOF円柱D4/H4 mmの試験です。横周期寸法固定。載荷中の充填層領域空隙率10.0652%、軸圧縮34.4863%、公称圧力0.158529 MPa。最終仕様100 mm角・円柱D20/H20 mmの解析ではありません。メッシュ収束は未合格です。

data/state-0000.npzは実際の直前の受理状態10.4342%、state-0001.npzは今回の終点です。材料履歴と参照体積・親要素対応を保存しています。元の実行設定はexecuted-config.json、data/config.jsonは数値予測用の旧ファイルパスを除去した移植用です。物理条件は変更していません。骨格の現在体積には弾性圧縮を含みます。

calculation-source-sha256.jsonに記録した16計算ソースは、実際に実行した凍結ソースと全てSHA-256が一致します。source/には独立監査に必要なPythonコードも含みます。古い作業フォルダを参照しないlocal-only監査を別の作業ディレクトリから実行し、audit.jsonに合格結果を保存しました。

Python3.12の対応環境で依存関係を用意してから、展開先を作業ディレクトリとして実行します。インストールは計算コードの外で行います。

```bash
python -m pip install -r source/requirements-parallel.txt
PYTHONPATH=source OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python source/tools/audit_rigid_compaction.py --run data --physics-config original-physics.json --local-predecessors-only --out my-recheck.json
```

この再計算は保存終点の力・構成則履歴・形状の独立リプレイです。初期40%からの全圧縮を新たに実行したという意味ではありません。全経路CSV・全履歴と全ケースの不採用試行は別の公開データを参照します。
