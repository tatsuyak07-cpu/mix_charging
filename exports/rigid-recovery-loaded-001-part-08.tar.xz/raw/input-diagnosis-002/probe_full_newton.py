from pathlib import Path
import json,time,numpy as np
from scipy.sparse import diags
from packing_fem.rigid_inclusion import make_periodic,make_contact
from packing_fem.explicit_material import geometry
from packing_fem.implicit_material import evaluate
from packing_fem.sparse_factor import factorize
from packing_fem.quasistatic_coupled import violation_merit

root=Path('/workspace/mix_charging/results/rigid-stages-1-4-001')
state=root/'continuation-012/state-0001.npz'
trace=root/'continuation-012/iterate-trace/iterate-1794643539016131120-0070.npz'
old=dict(np.load(state));trial=dict(np.load(trace))
for key,other in [('X','X'),('t','t'),('q','oldq'),('b','b'),('ep','ep')]:
    assert np.array_equal(old[key],trial[other]),key
c=json.loads((root/'continuation-012/config.json').read_text())
p=make_periodic(old['X'],c['length_mm'],c);contact=make_contact(old['X'],old['t'],p,c)
inverse=np.linalg.inv(geometry(old['x'],old['t'])[2]);q=trial['q'];t=old['t']
def values(v,tangent=False):
    _,gm,Km,_=evaluate(p.positions(v),t,old['b'],old['ep'],inverse,old['V0'],dict(c,implicit_project_material_tangent=False),tangent,old['parent'])
    _,gc,Kc,_=contact.evaluate_coupled(v,old['q'],tangent)
    g=(np.asarray(p.A.T@gm.ravel()).ravel()+gc)[:p.nmicro]
    J=None if not tangent else (p.A.T@Km@p.A+Kc)[:p.nmicro,:p.nmicro].tocsc()
    return g,J
g,J=values(q,True);merit,derivative=violation_merit(g,.004)
A=J+diags(np.maximum(abs(J.diagonal()),1e-6)*c['implicit_regularization'])
factor=factorize(A,c);d=np.zeros(p.ndof);d[:p.nmicro]=factor.solve(-g)
slope=float(derivative@(J@d[:p.nmicro]));bound=contact.ccd(q,d);alpha=1. if bound>=1 else .9*bound
rows=[]
for i in range(12):
    try:
        gradient,_=values(q+alpha*d);m,_=violation_merit(gradient,.004)
        row=dict(alpha=alpha,merit=m,maximum_N=float(abs(gradient).max()),l2_N=float(np.linalg.norm(gradient)),armijo=bool(m<=merit+1e-4*alpha*slope),rigid_balance=bool(contact.force_balance_ok(q+alpha*d,.005)))
    except (ValueError,RuntimeError) as e:row=dict(alpha=alpha,rejected=str(e))
    rows.append(row);print(json.dumps(row),flush=True)
    if row.get('armijo'):break
    alpha*=.5
report=dict(scope='Unaccepted numerical-direction diagnostic, no material/history advancement.',accepted_predecessor=str(state),trace=str(trace),initial_merit=merit,initial_maximum_N=float(abs(g).max()),initial_l2_N=float(np.linalg.norm(g)),full_newton_merit_slope=slope,ccd_bound=bound,direction_max_mm=float(abs(d[:p.nmicro]).max()),candidates=rows)
(root/'full-newton-direction-001.json').write_text(json.dumps(report,indent=2)+'\n')
