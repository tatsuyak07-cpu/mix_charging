from pathlib import Path
import csv,json,hashlib,shutil,subprocess,sys,os,zipfile
root=Path('/workspace/mix_charging');work=root/'results/rigid-stages-1-4-001';run=work/'continuation-017';stage=Path('/workspace/environment/mix_charging/endpoint-replay-001');stage.mkdir()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
status=json.loads((run/'status.json').read_text());assert status['target_reached']
with (run/'history.csv').open() as f:row=list(csv.DictReader(f))[-1]
assert abs(float(row['porosity'])-.1)<=.001
step=int(row['step']);data=stage/'data';data.mkdir()
shutil.copy2(run/f'state-{step-1:04d}.npz',data/'state-0000.npz');shutil.copy2(run/f'state-{step:04d}.npz',data/'state-0001.npz')
config=json.loads((run/'config.json').read_text());shutil.copy2(run/'config.json',stage/'executed-config.json');config.pop('implicit_previous_accepted_state',None);config['implicit_slip_predictor']=False;config['usage_scope']='Saved final increment for independent original-physics replay; numerical predictor path removed for portability.'
(data/'config.json').write_text(json.dumps(config,indent=2)+'\n');(data/'status.json').write_text(json.dumps(status,indent=2)+'\n');row['original_step']=step;row['step']=1
with (data/'history.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(row));w.writeheader();w.writerow(row)
shutil.copy2(work/'input/original-config.json',stage/'original-physics.json');shutil.copy2(work/'input/original-mesh.npz',stage/'original-mesh.npz')
source=stage/'source';source.mkdir()
for directory in ['packing_fem','tools']:
 for p in sorted((root/directory).rglob('*')):
  if p.is_file() and p.suffix in ['.py','.c','.cc','.cpp','.h','.hpp'] and '__pycache__' not in p.parts:
   target=source/p.relative_to(root);target.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,target)
for name in ['AGENTS.md','requirements-parallel.txt','requirements-implicit.txt','requirements-lock.txt','pyproject.toml']:shutil.copy2(root/name,source/name)
calculation=json.loads((run/'source-sha256.json').read_text())
for name,expected in calculation.items():assert sha(source/name)==expected,name
(stage/'calculation-source-sha256.json').write_text(json.dumps(calculation,indent=2)+'\n')
command=[sys.executable,str(source/'tools/audit_rigid_compaction.py'),'--run',str(data),'--physics-config',str(stage/'original-physics.json'),'--local-predecessors-only','--out',str(stage/'audit.json')]
environment=dict(os.environ,PYTHONPATH=str(source),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='4',PYTHONDONTWRITEBYTECODE='1')
with (stage/'replay.log').open('x') as log:subprocess.run(command,cwd=stage,env=environment,stdout=log,stderr=subprocess.STDOUT,check=True)
audit=json.loads((stage/'audit.json').read_text());assert audit['passed'];assert audit['states'][-1]['state_sha256']==sha(data/'state-0001.npz')
(stage/'README.md').write_text("""# 保存終点の独立再計算用データ

16粒子D10 mm・ネック2 mm、周期セル24.1407 mm角、自由6DOF円柱D4/H4 mmの試験です。横周期寸法固定。載荷中の充填層領域空隙率10.0652%、軸圧縮34.4863%、公称圧力0.158529 MPa。最終仕様100 mm角・円柱D20/H20 mmの解析ではありません。メッシュ収束は未合格です。

data/state-0000.npzは実際の直前の受理状態10.4342%、state-0001.npzは今回の終点です。材料履歴と参照体積・親要素対応を保存しています。元の実行設定はexecuted-config.json、data/config.jsonは数値予測用の旧ファイルパスを除去した移植用です。物理条件は変更していません。骨格の現在体積には弾性圧縮を含みます。

calculation-source-sha256.jsonに記録した16計算ソースは、実際に実行した凍結ソースと全てSHA-256が一致します。source/には独立監査に必要なPythonコードも含みます。古い作業フォルダを参照しないlocal-only監査を別の作業ディレクトリから実行し、audit.jsonに合格結果を保存しました。

Python3.12の対応環境で依存関係を用意してから、展開先を作業ディレクトリとして実行します。インストールは計算コードの外で行います。

```bash
python -m pip install -r source/requirements-parallel.txt
PYTHONPATH=source OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python source/tools/audit_rigid_compaction.py --run data --physics-config original-physics.json --local-predecessors-only --out my-recheck.json
```

この再計算は保存終点の力・構成則履歴・形状の独立リプレイです。初期40%からの全圧縮を新たに実行したという意味ではありません。全経路CSV・全履歴と全ケースの不採用試行は別の公開データを参照します。
""")
files=[dict(file=p.relative_to(stage).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(stage.rglob('*')) if p.is_file()]
archive=stage.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 for item in files:z.write(stage/item['file'],item['file'])
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={i['file'] for i in files}
 for item in files:assert hashlib.sha256(z.read(item['file'])).hexdigest()==item['sha256'],item['file']
assert archive.stat().st_size<100*1024**2
report=dict(passed=True,scope='Actual independent endpoint replay in isolated source/data directory; not full-path or mesh convergence.',source_files_matched_calculation=len(calculation),audit_passed=True,local_predecessors_only=True,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,all_zip_member_sha256_checked=True,files=files)
stage.with_name(stage.name+'-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='files'}),flush=True)
