"""Newton solve of the actual coupled solid/contact/Coulomb equilibrium residual."""
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import splu
from .fixed_point import affine_predictor
from .implicit_material import evaluate


def equilibrium(p,t,q,b,ep,inverse,V0,c,contact,prescribed,external,log,parent=None,initial_guess=None):
    oldq=q.copy();trial=q.copy() if initial_guess is None else initial_guess.copy()
    if prescribed is None or c.get('transverse_boundary')!='fixed_cell':return dict(reason='Coupled Newton requires prescribed axial compression and fixed transverse cell',iterate=trial)
    trial=affine_predictor(p,trial,prescribed)
    if np.any(abs(trial[-6:][[0,1,3,4,5]])>1e-12):return dict(reason='Fixed transverse lattice changed',iterate=trial)
    def values(v,tangent=False):
        _,g,Km,state=evaluate(p.positions(v),t,b,ep,inverse,V0,dict(c,implicit_project_material_tangent=False),tangent,parent)
        _,gc,Kc,n=contact.evaluate_coupled(v,oldq,tangent)
        internal=np.asarray(p.A.T@g.ravel()).ravel()+gc
        if not np.all(np.isfinite(internal)):raise ValueError('Nonfinite coupled force')
        J=None if not tangent else (p.A.T@Km@p.A+Kc)[:p.nmicro,:p.nmicro].tocsc()
        return internal,state,n,J
    try:
        for it in range(c.get('implicit_coupled_max_iterations',c['implicit_max_newton'])):
            internal,state,n,J=values(trial,True);gradient=(internal-external)[:p.nmicro]
            norm=float(np.max(abs(gradient),initial=0.));merit=.5*float(gradient@gradient)
            log(dict(coupled_newton=it,compression=float(-trial[p.prescribed]),residual_N=norm,residual_l2_N=float(np.linalg.norm(gradient)),contacts=n))
            if norm<c['implicit_force_tolerance_N']:return trial,state,internal,n,it,norm
            diagonal=np.maximum(abs(J.diagonal()),1e-6);dq=np.zeros(p.ndof)
            try:
                factor=splu(J+diags(diagonal*c['implicit_regularization']),permc_spec='COLAMD')
                dq[:p.nmicro]=factor.solve(-gradient);del factor
            except RuntimeError:dq[:p.nmicro]=np.nan
            merit_gradient=np.asarray(J.T@gradient).ravel()
            slope=float(merit_gradient@dq[:p.nmicro])
            if not np.all(np.isfinite(dq)) or not np.isfinite(slope) or slope>=0:
                column_norm=np.asarray(J.power(2).sum(axis=0)).ravel()
                dq[:p.nmicro]=-merit_gradient/np.maximum(column_norm,1e-12)
                slope=float(merit_gradient@dq[:p.nmicro]);log(dict(coupled_merit_gradient_fallback=True))
            if not np.all(np.isfinite(dq)) or not np.isfinite(slope) or slope>=0:raise ValueError('No coupled residual descent direction')
            bound=contact.ccd(trial,dq);alpha=1. if bound>=1 else .9*bound
            accepted=False
            for ls in range(35):
                candidate=trial+alpha*dq
                try:
                    ci,_,_,_=values(candidate);cg=(ci-external)[:p.nmicro];candidate_merit=.5*float(cg@cg)
                    if candidate_merit<=merit+1e-4*alpha*slope:
                        accepted=True;break
                except (ValueError,RuntimeError):pass
                alpha*=.5
            if not accepted:raise ValueError('Coupled residual line search failed')
            log(dict(coupled_alpha=alpha,merit_before_N2=merit,merit_after_N2=candidate_merit))
            trial=candidate
        raise ValueError('Coupled Newton iteration budget exhausted')
    except (ValueError,RuntimeError) as exc:return dict(reason=str(exc),iterate=trial)
