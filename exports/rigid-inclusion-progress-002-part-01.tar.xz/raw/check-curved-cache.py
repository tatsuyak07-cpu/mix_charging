from pathlib import Path
import json,time,gc
import numpy as np
from packing_fem.rigid_inclusion import make_periodic,make_contact
from tools.audit_rigid_compaction import load
root=Path('results/rigid-inclusion-001');run=root/'compression-001';trace=load(run/'iterate-trace/iterate-1794285582522051168-0060.npz');old=load(run/'state-0002.npz');c=json.loads((run/'config.json').read_text());p=make_periodic(trace['X'],c['length_mm'],c);q=trace['q'];d=np.zeros_like(q);d[p.rigid_dofs[3:]]=[.001,-.002,.001]
cache=make_contact(trace['X'],trace['t'],p,dict(c,ipc_cache_swept_candidates=True));bound=cache.ccd(q,d);query=q+.3*bound*d;t=time.monotonic();a=cache.evaluate_coupled(query,old['q']);cached=time.monotonic()-t;assert cache.last_collision_cache_hit
fresh=make_contact(trace['X'],trace['t'],p,dict(c,ipc_cache_swept_candidates=False));t=time.monotonic();b=fresh.evaluate_coupled(query,old['q']);uncached=time.monotonic()-t
report=dict(passed=bool(a[3]==b[3] and abs(a[1]-b[1]).max()<1e-8),contacts_cached=a[3],contacts_fresh=b[3],maximum_force_difference_N=float(abs(a[1]-b[1]).max()),cached_evaluation_s=cached,fresh_evaluation_s=uncached,note='Same physical query and force law; individual timing diagnostic, not whole-model speed claim.')
pth=root/'curved-cache-comparison.json';assert not pth.exists();pth.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True);assert report['passed']
